# O Último Bastião — Design System

Referências: Berserk (clima), Darkest Dungeon (arte/UI), Kingdom Rush (legibilidade), Castlevania, Diablo (itens).
Regra de ouro: **escuro por padrão, cor só significa algo.** Vermelho = perigo/sangue/runa. Dourado = fogo/valor. Roxo = corrupção.

---

## 1. Paleta

Extraída dos sprites da pasta.

| Token | Hex | Uso | Presente em |
|---|---|---|---|
| `void` | `#0B0A0D` | fundo, outline 1px | todos |
| `stone-900` | `#1C1B22` | painéis | Torre Negra |
| `stone-700` | `#2E2C36` | bordas de painel | Torre Negra, ruínas |
| `stone-500` | `#4A4852` | texto desabilitado | armaduras |
| `iron` | `#8A8C8E` | texto secundário, metal | cavaleiros cinza |
| `bone` | `#E8DCC0` | texto principal | caveira do estandarte, velas |
| `blood` | `#8B1A1A` | HP, dano, perigo | tabardo do Comandante |
| `rune` | `#FF2A2A` | olhos, runas, crítico (glow) | Comandante, boss, runas |
| `ember` | `#F2A33A` | fogo, ouro, seleção | tochas, velas |
| `gold-old` | `#A8894A` | raridade, bordas nobres | — |
| `rust` | `#6B3F26` | madeira, couro | orc, porta, torre de madeira |
| `moss` | `#3F5A2E` | vegetação, veneno | torre arruinada, pele do orc |
| `corruption` | `#5B2A7A` | magia proibida, aura boss | boss, topo torre arruinada |
| `night-teal` | `#1E2A2A` | chão/fundo noturno | folha de sprites |

Nunca usar branco puro nem preto puro em áreas grandes (preto só no outline).

## 2. Pixel art

Pixel art HD detalhada. Tamanhos, PPU, frames e escala: **ver [asset-spec.md](asset-spec.md)** (fonte única).

| Regra | Valor |
|---|---|
| Filtro | Point (no filter), compressão None |
| Outline | 1px `void`, sempre |
| Luz | vem de cima-esquerda |

## 3. Tipografia

| Papel | Fonte | Tamanho (px internos) |
|---|---|---|
| Títulos ("NOITE 12") | **Pixel gótica** — *Alagard* | 16 / 32 |
| Texto / números | *m5x7* ou *Pixel Operator* | 8 / 16 |

Títulos em `bone` com sombra 1px `blood`. Números de dano: `rune` (crítico), `bone` (normal), `moss` (cura).

## 4. Componentes de UI

- **Painel**: fundo `stone-900` 90% opaco, borda 2px `stone-700`, cantos com rebite `iron` 2×2. Sem cantos arredondados.
- **Barra de HP**: fundo `void`, preenchimento `blood`, perda recente em `ember` que desliza em 0.4s.
- **Barra de Moral**: segmentos `████████░░` em `gold-old`; abaixo de 30 pisca `rune`.
- **Botão**: `stone-700` → hover `stone-500` + texto `ember` → pressionado desce 1px.
- **Tooltip de relíquia**: título em `gold-old`, bônus em `bone`, maldição em `rune` itálico.
- **Ficha de unidade**: retrato + nome + feridas como ícones cicatriz (`blood`).
- **Anúncio de noite**: tela escurece, "NOITE 20" centralizado, 1.5s, som de sino.

## 5. Efeitos

| Efeito | Visual |
|---|---|
| Corrupção | partículas `corruption` quadradas 1–2px subindo |
| Glow de runa/olho | pixel `rune` + halo aditivo 30% |
| Tocha | flicker de 3 frames, luz `ember` 2D (PointLight2D) |
| Hit | flash branco-`bone` 1 frame + screen shake 2px |
| Fúria | Comandante com tint `blood`, olho deixa rastro |
| Noite | CanvasModulate `#3A3A55`; só tochas/runas iluminam |

## 6. Sprites disponíveis

> ⚠️ Todos os arquivos são **JPG com o xadrez de transparência "pintado"** na imagem — não há alpha real. Antes de usar: remover o fundo (Aseprite/Photoshop/`rembg`) e exportar **PNG**. Também reduzir para a resolução real de pixel (as imagens estão ampliadas ~8–16×, redimensionar com *nearest*).

| Arquivo | Renomear para | Conteúdo | Uso no jogo |
|---|---|---|---|
| `182d48e5…jpg` | `tower_black.png` | Torre de pedra negra, runas vermelhas, velas, bandeira demoníaca | **Núcleo / Torre Negra** |
| `a6b7b87b…jpg` | `tower_ruined.png` | Torre de madeira isométrica, gárgulas, topo roxo | **Torre de Vigia** / estrutura corrompida |
| `9e8a1bac…jpg` | `commander.png` | Cavaleiro negro, olho vermelho, espada gigante (frente + perfil) | **Comandante** (e base do Cavaleiro Negro inimigo) |
| `7e12e66a…jpg` | `enemy_orc.png` | Guerreiro orc/morto-vivo, espada e escudo de madeira | **Soldado Amaldiçoado** |
| `da63c9a8…jpg` | `boss_cursed_knight.png` | Boss roxo com espadão, aura, texto "BOSS: CURSED KNIGHT." | **Boss final** (cortar o texto) |
| `ba12be6a…jpg` | `sheet_allies.png` | Folha: 25 cavaleiros cinza, encapuzados (com/sem rosto), 3 ruínas, 4 tochas, estandartes corvo/caveira | tropas, monges, magos, ruínas, tochas, estandartes |

Folha `sheet_allies` já tem fundo sólido `night-teal` (não xadrez) — dá para recortar com chroma key.

Faltam: arqueiro, animações (idle/walk/attack/death), tiles de chão, ícones de recursos, ferreiro/capela/calabouço.

Esses 6 arquivos são **referência de estilo**, não assets finais — os finais saem do padrão em [asset-spec.md](asset-spec.md).

## 7. Estrutura de pastas (Unity)

```
Assets/
  Art/Sprites/{Units,Enemies,Structures,Props}/
  Art/UI/
  Fonts/
  Scenes/
  Scripts/
  Data/          ScriptableObjects de unidades/inimigos/ondas ← números do rules.md
```

Números de balanceamento ficam em ScriptableObjects, nunca hardcoded — o `rules.md` é a fonte.
