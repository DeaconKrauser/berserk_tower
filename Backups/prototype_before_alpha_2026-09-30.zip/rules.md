# O Último Bastião: Eclipse Negro — Regras

Tower defense dark fantasy. Você não constrói "torres bonitinhas": defende uma fortaleza no fim do mundo com muralhas, tropas e um Comandante que luta junto. Se ele morrer, a run acaba.

Engine: **Unity 6 + C#, URP 2D Renderer**. PC/Steam, 16:9, 1920×1080. Câmera 3/4 levemente isométrica. Mundo, criaturas e símbolos próprios — Berserk só como clima, nada copiado.

## 0. Vertical slice (escopo atual)

Só isto entra no primeiro build. O resto deste documento é o jogo completo.

- 1 mapa, **10 ondas**, boss na onda 10
- Comandante
- Tropas: arqueiro, lanceiro
- Estruturas: núcleo, torre de arqueiros, ferreiro, capela, muralha de madeira
- Inimigos: Soldado Amaldiçoado, Encapuzado, Cão Carniçal (rápido), Cavaleiro Negro + boss Cavaleiro Amaldiçoado
- Sistemas: construir/reparar/recrutar entre ondas, moral simples. **Fora:** relíquias, feridas, calabouço, IA adaptativa, save.

---

## 1. Loop principal

```
DIA   → construir / reparar / recrutar / equipar relíquias
NOITE → onda de inimigos (tempo real, pausável)
AMANHECER → feridas, moral, saque, evento narrativo
```

Uma run = 50 noites. Noite 50: **Cavaleiro Amaldiçoado** (boss final).

## 2. Vitória e derrota

| Condição | Resultado |
|---|---|
| Sobreviver à noite 50 e matar o boss | Vitória |
| Comandante morre | Derrota imediata (permadeath) |
| Torre Negra (núcleo) destruída | Derrota |
| Moral global = 0 | Motim: derrota |

## 3. Recursos

| Recurso | Fonte | Uso |
|---|---|---|
| **Ferro** | saque, mina | muralhas, armas |
| **Madeira** | serraria | muralhas de madeira, arqueiros |
| **Almas** | inimigos mortos | relíquias, magos proibidos |
| **Fé** | capela | cura, proteção contra magia |
| **Homens** | refugiados (evento de amanhecer) | recrutar tropas |

## 4. Estruturas

Construídas só de dia, em slots do grid isométrico.

| Estrutura | Sprite | Custo | Efeito |
|---|---|---|---|
| **Torre Negra** (núcleo) | `tower_black` | — | HP 2000. Perdeu = fim. Runas vermelhas brilham conforme HP cai |
| **Torre de Vigia** | `tower_ruined` | 40 madeira | +25% alcance de arqueiros em raio 3 |
| Muralha madeira / pedra / ferro negro | tiles de ruína | 10 / 25 ferro / 20 ferro + 10 almas | HP 150 / 400 / 800 |
| Ferreiro | — | 60 ferro | +1 tier de arma por upgrade |
| Capela | — | 30 madeira, 20 fé | cura 5 HP/s em raio 2 |
| Calabouço | — | 80 ferro | captura 1 inimigo/noite → pesquisa |
| Tocha | `torch` | 5 madeira | ilumina área; inimigos no escuro têm +30% esquiva |
| Estandarte | `banner_raven` / `banner_skull` | 15 madeira | Corvo: +10 moral em raio. Caveira: inimigos −10% dano em raio |

Estruturas destruídas viram **ruína** (`ruin_*`) e custam 50% para reconstruir.

## 5. Tropas

| Unidade | Sprite | HP | Dano | Alcance | Nota |
|---|---|---|---|---|---|
| Soldado | `knight_*` (cinza) | 120 | 12 | corpo | base, barato |
| Lanceiro | `knight_*` | 140 | 10 | 1.5 | +100% contra cavalaria/grandes |
| Arqueiro | a criar | 70 | 8 | 6 | precisa de linha de visão |
| Cavaleiro | `knight_*` com escudo | 220 | 18 | corpo | lento, bloqueia 1 golpe a cada 5s |
| Monge | `hooded_face` (rosto visível) | 80 | 0 | 3 | cura, +moral |
| Mago Proibido | `hooded_void` (sem rosto) | 60 | 40 AoE | 5 | cada cast: 5% chance de corrupção |

Ordens: **Avançar · Segurar · Recuar · Parede de Escudos · Sacrificar** (unidade explode em moral: +30 moral aos vizinhos).

## 6. Comandante

Sprite: `commander` (cavaleiro negro, olho vermelho, espada gigante). Controlado diretamente (WASD / clique).

```
HP 600 · Dano 45 (golpe amplo, 120°) · Vel 1.0
Habilidade: Fúria — 8s, +100% dano, não recebe cura, −20 moral própria ao fim
Traço fixo: Não recua (não aceita ordem de Recuar)
```

Ferimentos são permanentes (ver §8). Ele pode carregar até 3 relíquias.

## 7. Inimigos

| Inimigo | Sprite | HP | Vel | Regra |
|---|---|---|---|---|
| Soldado Amaldiçoado | `enemy_orc` | 500 | lenta | renasce 1x com 50% HP |
| Cavaleiro Negro | `commander` recolorido roxo | 900 | média | ignora flechas (−80% dano ranged) |
| Encapuzado | `hooded_void` recolorido | 150 | rápida | corrompe tropas próximas (−moral) |
| **Cavaleiro Amaldiçoado** (boss) | `boss_cursed_knight` | 20000 | lenta | destrói estruturas em 1 golpe; fase 2 a 50% HP: aura −5 moral/s |

Escala por noite `n`:
```
quantidade = 100 * 1.1^(n-1)     (noite 1: 100 · noite 20: ~610 · limitar a 5000)
hp_mult    = 1 + 0.04 * (n-1)
mini-boss a cada 10 noites
```

### IA adaptativa dos comandantes inimigos
Cada comandante inimigo guarda o que o matou na noite anterior (ex.: 70% por arqueiros) e ajusta a próxima onda: mais cavaleiros negros contra arqueiros, mais encapuzados contra muralhas densas, ataca o lado com menos tochas.

## 8. Feridas e veteranos

Toda unidade que cai abaixo de 20% HP e sobrevive rola 1 ferida:

| Ferida | Efeito |
|---|---|
| Perdeu um olho | −20% alcance, +10% crítico |
| Perdeu dedos | −10% vel. de ataque, +15% dano |
| Cicatriz profunda | +20% HP máx, −5 moral |
| Loucura | 10% chance/noite de atacar aliado |

A cada 5 noites sobrevividas: **Veterano** (+10% todos os status). Nome e histórico aparecem na ficha (ex.: "Sir Aldren — perdeu um olho na noite 12").

## 9. Moral

Por unidade, 0–100. Global = média.

| Evento | Moral |
|---|---|
| Aliado morre perto (raio 2) | −10 |
| Comandante perto | +2/s até 80 |
| Estandarte Corvo | +10 fixo |
| Boss em tela | −1/s |

| Faixa | Efeito |
|---|---|
| < 30 | 25% chance/10s de fugir |
| < 15 | deserta ao amanhecer |
| 0 global | motim → derrota |

## 10. Relíquias amaldiçoadas

Dropam de mini-bosses. Sempre um bônus forte e um custo.

| Relíquia | Bônus | Maldição |
|---|---|---|
| Espada do Eclipse | +50% dano | 10%/noite de enlouquecer |
| Marca do Sacrifício | +1 vida para o Comandante | cada noite custa 5 Homens |
| Olho do Abismo | vê composição da próxima onda | −10 moral global permanente |

## 11. Controles

| Ação | Tecla |
|---|---|
| Mover Comandante | WASD / clique direito |
| Atacar / Fúria | clique esq. / Espaço |
| Selecionar tropas | arrastar caixa |
| Ordens | 1–5 |
| Pausar | P (dá ordens pausado) |

## 12. Save

Save automático no amanhecer (JSON em `Application.persistentDataPath`). Permadeath: só existe 1 slot por run.
