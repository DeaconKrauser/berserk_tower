"""Builds every cutout rig: parts + rig.json + clips.json into Assets/Art/Animations/<Name>/.

    python tools/build_rigs.py                 # all characters
    python tools/build_rigs.py Commander       # one
    python tools/build_rigs.py --preview       # also contact sheets in Assets/Art/Generated/_debug/rigs

Unity side: menu "Bastião/Reconstruir rigs" (Assets/Editor/RigBuilder.cs) turns them into prefabs + Animator.
"""
import os
import sys

import numpy as np

import figures_src
import rig_motion
from rig_defs import CHARACTERS
from rigkit import ANIM_DIR, Rig, contact_sheet

DEBUG_DIR = os.path.join(os.path.dirname(ANIM_DIR), "Generated", "_debug", "rigs")
_cache = {}


def load_figure(name):
    if name not in _cache:
        _cache[name] = figures_src.figure(name)
    return _cache[name]


def build(name, spec, preview=False):
    rgb, alpha = spec["source"]() if "source" in spec else load_figure(spec["figure"])
    if "recolor" in spec:
        rgb = spec["recolor"](rgb, alpha)
    rig = Rig(name, rgb, alpha, spec["height"], spec["parts"], feet=spec.get("feet"),
              palette_k=spec.get("palette", 40)).cut()
    motion = dict(spec["motion"])
    kind = motion.pop("kind")
    clips = getattr(rig_motion, kind)(motion)
    if "extra_clips" in spec:
        clips.update(spec["extra_clips"](rig))
    extra = spec.get("rig_extra", {})
    if "post" in spec:
        extra = spec["post"](rig, clips) or extra
    rig.export(clips, extra)
    if preview:
        os.makedirs(DEBUG_DIR, exist_ok=True)
        rig.overlay(os.path.join(DEBUG_DIR, f"{name}_parts.png"))
        names = [c for c in ("Idle", "Walk", "Run", "Attack", "Hit", "Death", "Cast", "Special", "Intro", "Spawn") if c in clips]
        contact_sheet(rig, clips, os.path.join(DEBUG_DIR, f"{name}_clips.png"), frames=6, zoom=3, names=names)
    print(f"rig {name}: {len(rig.images)} parts, {rig.out_w}x{rig.out_h}px, clips {sorted(clips)}")
    return rig, clips


if __name__ == "__main__":
    preview = "--preview" in sys.argv
    wanted = [a for a in sys.argv[1:] if not a.startswith("--")] or list(CHARACTERS)
    for n in wanted:
        build(n, CHARACTERS[n], preview)
