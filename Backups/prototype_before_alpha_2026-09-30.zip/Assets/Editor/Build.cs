using UnityEditor;

public static class Build
{
    // Unity.exe -batchmode -quit -projectPath . -executeMethod Build.Windows
    public static void Windows() =>
        BuildPipeline.BuildPlayer(new[] { "Assets/Scenes/SampleScene.unity" }, "Build/Bastiao.exe",
            BuildTarget.StandaloneWindows64, BuildOptions.None);
}
