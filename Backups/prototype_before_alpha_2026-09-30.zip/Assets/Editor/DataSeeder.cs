using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

// TEMPORARY: writes the first version of the balance assets. Delete once the assets are the source of truth.
public static class DataSeeder
{
    const string D = "Assets/Data";

    public static void SeedAndBuild()
    {
        Seed();
        Build.Windows();
    }

    [MenuItem("Bastião/Recriar dados iniciais")]
    public static void Seed()
    {
        CharacterAnimBuilder.BuildAll();

        var arrow = Projectile("Arrow", "arrow", 17, 0.35f, true, Hex("E8DCC0"));
        var bolt = Projectile("Bolt", "bolt", 24, 0.05f, true, Hex("8A8C8E"));
        var fire = Projectile("Fireball", "fireball", 7.5f, 1.4f, false, Hex("B048D8"));

        // name, hp, armor, physRes, fireRes, speed, radius, bounty, lives, atk, atkInterval
        var soldier = Enemy("CursedSoldier", "Soldado Amaldiçoado", 145, 3, 0, -0.25f, 1.0f, 0.3f, 5, 1, 10, 1.3f);
        var hound = Enemy("Hound", "Cão Carniçal", 52, 0, 0, 0, 2.2f, 0.4f, 3, 1, 6, 0.7f);
        var hooded = Enemy("Hooded", "Encapuzado", 190, 1, -0.2f, 0.6f, 1.15f, 0.3f, 8, 2, 14, 1.2f);
        var knight = Enemy("BlackKnight", "Cavaleiro Negro", 760, 14, 0, 0, 0.7f, 0.42f, 22, 3, 35, 1.5f);
        var boss = Enemy("CursedKnight", "Cavaleiro Amaldiçoado", 6000, 12, 0.35f, -0.15f, 0.5f, 0.9f, 250, 20, 110, 2f);
        boss.isBoss = true;
        boss.summon = soldier;
        boss.summonCount = 2;
        boss.summonInterval = 14;
        boss.enrageBelowHp = 0.4f;
        boss.enrageSpeedMultiplier = 1.6f;
        boss.lightColor = new Color(0.6f, 0.25f, 0.9f);
        boss.lightRadius = 4.5f;

        var archer = Tower("Archer", "Torre de Arqueiros", "Rápida e barata · alvo único · sofre contra armadura", 70, arrow,
            TargetPriority.First, 1.9f, 0, Color.white,
            Atk(10, 0.6f, 3.8f),
            Up("Arcos Longos", "Arqueiros veteranos: alcance bem maior.", 110, Atk(12, 0.55f, 4.5f)),
            Up("Flechas Farpadas", "Pontas de ferro negro atravessam couro e malha.", 170, Atk(16, 0.5f, 4.7f, pen: 3)),
            Up("Chuva de Flechas", "Dispara em dois alvos por vez.", 260, Atk(18, 0.42f, 4.8f, pen: 4, targets: 2)));
        var ballista = Tower("Ballista", "Balista", "Lenta · alcance longo · perfura armadura · caça o mais resistente", 140, bolt,
            TargetPriority.Strongest, 1.1f, 0, Color.white,
            Atk(70, 2.5f, 5.0f, pen: 8),
            Up("Molas de Ferro Negro", "Tensão maior: mais dano e alcance.", 210, Atk(95, 2.3f, 5.4f, pen: 11)),
            Up("Virotes Rúnicos", "Runas de sangue rasgam placas de aço.", 310, Atk(140, 2.1f, 5.8f, pen: 16)),
            Up("Matadora de Colossos", "Feita para derrubar o que anda sobre os mortos.", 460, Atk(210, 1.9f, 6.3f, pen: 24)));
        var pyre = Tower("Pyre", "Pira Amaldiçoada", "Fogo em área · ignora armadura · fraca contra encapuzados", 120, fire,
            TargetPriority.First, 1.3f, 2.4f, new Color(1f, 0.45f, 0.4f),
            Atk(15, 1.7f, 3.2f, splash: 1.2f, type: DamageType.Fire),
            Up("Óleo de Cadáver", "As chamas grudam: inimigos continuam queimando.", 180, Atk(19, 1.6f, 3.4f, splash: 1.4f, burn: 5, burnFor: 2.5f, type: DamageType.Fire)),
            Up("Chamas Negras", "Fogo mais largo e mais cruel.", 270, Atk(26, 1.5f, 3.6f, splash: 1.6f, burn: 9, burnFor: 3, type: DamageType.Fire)),
            Up("Inferno do Eclipse", "Uma cratera de fogo sobre a estrada.", 400, Atk(36, 1.35f, 3.9f, splash: 2.0f, burn: 14, burnFor: 3, type: DamageType.Fire)));
        var chapel = Tower("Chapel", "Capela de Guerra", "Suporte · fortalece torres próximas · cura o comandante", 130, null,
            TargetPriority.First, 1.5f, 2.0f, new Color(1f, 0.82f, 0.5f),
            Aura(3.0f, dmg: 0.15f, heal: 5),
            Up("Cânticos de Batalha", "Os arqueiros atiram mais rápido.", 190, Aura(3.3f, dmg: 0.2f, speed: 0.1f, heal: 8)),
            Up("Relicário dos Mártires", "Ossos santos: alcance maior para as torres.", 290, Aura(3.6f, dmg: 0.25f, speed: 0.15f, range: 0.1f, heal: 12)),
            Up("Marca da Heresia", "Inimigos na aura perdem armadura.", 430, Aura(4.0f, dmg: 0.3f, speed: 0.2f, range: 0.12f, shred: 5, heal: 18)));

        var waves = new List<WaveData>
        {
            Wave(1, "Os Primeiros Mortos", G(soldier, 8, 1.4f), G(soldier, 6, 1.2f, 6)),
            Wave(2, "Carne Fresca", G(soldier, 10, 1.1f), G(soldier, 8, 0.9f, 5)),
            Wave(3, "A Matilha", G(soldier, 8, 1.0f), G(hound, 8, 0.55f, 4), G(soldier, 8, 0.9f, 4)),
            Wave(4, "Os Encapuzados", G(soldier, 10, 0.9f), G(hooded, 6, 1.4f, 3), G(hound, 10, 0.5f, 5)),
            Wave(5, "Aço Negro", G(soldier, 16, 0.8f), G(knight, 2, 5f, 4), G(hooded, 8, 1.2f, 3), G(hound, 14, 0.45f, 4)),
            Wave(6, "Maré de Ossos", G(soldier, 36, 0.35f), G(hound, 16, 0.4f, 6), G(hooded, 10, 1.0f, 3)),
            Wave(7, "Uivos na Névoa", G(hound, 24, 0.35f), G(soldier, 18, 0.6f, 3), G(hound, 24, 0.3f, 5)),
            Wave(8, "Muralha de Ferro", G(knight, 5, 3f), G(soldier, 20, 0.6f, 2), G(hooded, 12, 0.9f, 3), G(knight, 3, 2.5f, 4)),
            Wave(9, "A Horda", G(soldier, 50, 0.3f), G(hound, 24, 0.35f, 4), G(hooded, 14, 0.8f, 3), G(knight, 6, 2f, 4)),
            Wave(10, "O Cavaleiro Amaldiçoado", G(soldier, 20, 0.5f), G(hooded, 10, 0.8f, 3), G(boss, 1, 1f, 6), G(soldier, 20, 0.6f, 10), G(hound, 20, 0.4f, 8)),
        };

        EnsureFolder("Assets/Resources");
        var level = Asset<LevelData>("Assets/Resources/Level01.asset");
        level.startingGold = 260;
        level.lives = 20;
        level.waveClearBonus = 20;
        level.waveClearBonusPerWave = 6;
        level.sellRefund = 0.7f;
        level.minPhysicalDamage = 0.15f;
        level.towers = new List<TowerData> { archer, ballista, pyre, chapel };
        level.waves = waves;
        level.commanderFront = Controller("Commander");
        level.commanderBack = Controller("CommanderBack");
        level.commanderHp = 650;
        level.commanderDamage = 40;
        level.commanderArmorPenetration = 4;
        level.commanderAttackInterval = 0.9f;
        level.commanderReach = 1.3f;
        level.commanderCleave = 3;
        level.commanderBlockCount = 3;
        level.commanderSpeed = 3.2f;
        EditorUtility.SetDirty(level);
        AssetDatabase.SaveAssets();
        Debug.Log("DataSeeder: ok");
    }

    // ---------------------------------------------------------------- builders

    static ProjectileData Projectile(string file, string sprite, float speed, float arc, bool homing, Color impact)
    {
        var p = Asset<ProjectileData>($"{D}/Projectiles/{file}.asset");
        p.sprite = S($"Assets/Sprites/Projectiles/{sprite}.png");
        p.speed = speed;
        p.arcHeight = arc;
        p.homing = homing;
        p.impactColor = impact;
        return p;
    }

    static EnemyData Enemy(string file, string name, float hp, float armor, float physRes, float fireRes, float speed,
        float radius, int bounty, int lives, float attack, float attackInterval)
    {
        var e = Asset<EnemyData>($"{D}/Enemies/{file}.asset");
        e.displayName = name;
        e.animator = Controller(file);
        e.maxHp = hp;
        e.armor = armor;
        e.physicalResistance = physRes;
        e.fireResistance = fireRes;
        e.speed = speed;
        e.bodyRadius = radius;
        e.bounty = bounty;
        e.livesCost = lives;
        e.attackDamage = attack;
        e.attackInterval = attackInterval;
        return e;
    }

    static TowerData Tower(string file, string name, string role, int cost, ProjectileData projectile, TargetPriority targeting,
        float muzzle, float lightRadius, Color lightColor, TowerStats stats, params (string name, string desc, int cost, TowerStats stats)[] ups)
    {
        var t = Asset<TowerData>($"{D}/Towers/{file}.asset");
        string sprite = file.ToLower();
        t.displayName = name;
        t.role = role;
        t.cost = cost;
        t.sprite = S($"Assets/Sprites/Towers/{sprite}_1.png");
        t.footprintRadius = 0.65f;
        t.muzzleHeight = muzzle;
        t.targeting = targeting;
        t.projectile = projectile;
        t.lightRadius = lightRadius;
        t.lightColor = lightColor;
        t.stats = stats;
        t.upgrades = ups.Select((u, i) =>
        {
            var a = Asset<TowerUpgradeData>($"{D}/Towers/Upgrades/{file}_{i + 2}.asset");
            a.displayName = u.name;
            a.description = u.desc;
            a.cost = u.cost;
            a.sprite = S($"Assets/Sprites/Towers/{sprite}_{i + 2}.png");
            a.stats = u.stats;
            return a;
        }).ToList();
        return t;
    }

    static (string, string, int, TowerStats) Up(string name, string desc, int cost, TowerStats stats) => (name, desc, cost, stats);

    static TowerStats Atk(float dmg, float interval, float range, float pen = 0, float splash = 0, int targets = 1,
        float burn = 0, float burnFor = 0, DamageType type = DamageType.Physical) => new()
    {
        damage = dmg, attackInterval = interval, range = range, armorPenetration = pen, splashRadius = splash,
        targets = targets, burnDps = burn, burnDuration = burnFor, damageType = type,
    };

    static TowerStats Aura(float radius, float dmg = 0, float speed = 0, float range = 0, float shred = 0, float heal = 0) => new()
    {
        auraRadius = radius, auraDamageBonus = dmg, auraAttackSpeedBonus = speed, auraRangeBonus = range,
        auraArmorShred = shred, commanderHealPerSecond = heal, attackInterval = 1, targets = 1,
    };

    static WaveData Wave(int n, string title, params SpawnGroup[] groups)
    {
        var w = Asset<WaveData>($"{D}/Waves/Wave{n:00}.asset");
        w.title = title;
        w.groups = groups.ToList();
        return w;
    }

    static SpawnGroup G(EnemyData e, int count, float interval, float delay = 0) =>
        new() { enemy = e, count = count, interval = interval, delay = delay };

    // ---------------------------------------------------------------- asset helpers

    static T Asset<T>(string path) where T : ScriptableObject
    {
        var a = AssetDatabase.LoadAssetAtPath<T>(path);
        if (!a)
        {
            EnsureFolder(path.Substring(0, path.LastIndexOf('/')));
            a = ScriptableObject.CreateInstance<T>();
            AssetDatabase.CreateAsset(a, path);
        }
        EditorUtility.SetDirty(a);
        return a;
    }

    static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        int i = path.LastIndexOf('/');
        EnsureFolder(path.Substring(0, i));
        AssetDatabase.CreateFolder(path.Substring(0, i), path.Substring(i + 1));
    }

    static Sprite S(string path) => AssetDatabase.LoadAssetAtPath<Sprite>(path);

    static RuntimeAnimatorController Controller(string name) =>
        AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>($"Assets/Animations/{name}.overrideController");

    static Color Hex(string hex) => ColorUtility.TryParseHtmlString("#" + hex, out var c) ? c : Color.white;
}
