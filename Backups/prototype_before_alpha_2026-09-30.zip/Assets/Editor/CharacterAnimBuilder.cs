using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

// Builds Assets/Animations from Assets/Sprites/Characters/<Name>/<state>_<frame>.png:
// one shared Character.controller (Idle, Walk, Attack, Hit, Death) + one override controller per character.
// Dropping final art with the same names and re-running keeps every reference intact.
public static class CharacterAnimBuilder
{
    const string SpriteRoot = "Assets/Sprites/Characters", OutRoot = "Assets/Animations";
    static readonly (string state, float fps, bool loop)[] States =
    {
        ("Idle", 6, true), ("Walk", 10, true), ("Attack", 12, false), ("Hit", 12, false), ("Death", 10, false),
    };

    [MenuItem("Bastião/Reconstruir animações dos personagens")]
    public static void BuildAll()
    {
        if (!AssetDatabase.IsValidFolder(OutRoot)) AssetDatabase.CreateFolder("Assets", "Animations");
        var baseController = BaseController();
        foreach (var dir in Directory.GetDirectories(SpriteRoot))
            Character(Path.GetFileName(dir), baseController);
        AssetDatabase.SaveAssets();
    }

    static AnimatorController BaseController()
    {
        string path = $"{OutRoot}/Character.controller";
        var existing = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
        if (existing) return existing;

        var c = AnimatorController.CreateAnimatorControllerAtPath(path);
        c.AddParameter("Moving", AnimatorControllerParameterType.Bool);
        c.AddParameter("Attack", AnimatorControllerParameterType.Trigger);
        c.AddParameter("Hit", AnimatorControllerParameterType.Trigger);
        c.AddParameter("Dead", AnimatorControllerParameterType.Bool);
        var sm = c.layers[0].stateMachine;
        var st = new Dictionary<string, AnimatorState>();
        foreach (var (name, _, _) in States)
        {
            var placeholder = new AnimationClip { name = "Base_" + name };
            AssetDatabase.AddObjectToAsset(placeholder, c);
            st[name] = sm.AddState(name);
            st[name].motion = placeholder;
        }
        sm.defaultState = st["Idle"];

        AnimatorStateTransition T(AnimatorStateTransition t, bool exit)
        {
            t.hasExitTime = exit;
            t.exitTime = 1;
            t.duration = 0;
            return t;
        }
        T(st["Idle"].AddTransition(st["Walk"]), false).AddCondition(AnimatorConditionMode.If, 0, "Moving");
        T(st["Walk"].AddTransition(st["Idle"]), false).AddCondition(AnimatorConditionMode.IfNot, 0, "Moving");
        var attack = T(sm.AddAnyStateTransition(st["Attack"]), false);
        attack.AddCondition(AnimatorConditionMode.If, 0, "Attack");
        attack.AddCondition(AnimatorConditionMode.IfNot, 0, "Dead");
        attack.canTransitionToSelf = true;
        T(st["Attack"].AddTransition(st["Idle"]), true);
        var hit = T(sm.AddAnyStateTransition(st["Hit"]), false);
        hit.AddCondition(AnimatorConditionMode.If, 0, "Hit");
        hit.AddCondition(AnimatorConditionMode.IfNot, 0, "Dead");
        hit.canTransitionToSelf = false;
        T(st["Hit"].AddTransition(st["Idle"]), true);
        var death = T(sm.AddAnyStateTransition(st["Death"]), false);
        death.AddCondition(AnimatorConditionMode.If, 0, "Dead");
        death.canTransitionToSelf = false;
        return c;
    }

    static void Character(string name, AnimatorController baseController)
    {
        string path = $"{OutRoot}/{name}.overrideController";
        var ov = AssetDatabase.LoadAssetAtPath<AnimatorOverrideController>(path);
        if (!ov)
        {
            ov = new AnimatorOverrideController(baseController);
            AssetDatabase.CreateAsset(ov, path);
        }
        ov.runtimeAnimatorController = baseController;
        var pairs = new List<KeyValuePair<AnimationClip, AnimationClip>>();
        ov.GetOverrides(pairs);
        var idle = Frames(name, "Idle");
        for (int i = 0; i < pairs.Count; i++)
        {
            var (state, fps, loop) = States.First(s => "Base_" + s.state == pairs[i].Key.name);
            var frames = Frames(name, state);
            pairs[i] = new(pairs[i].Key, Clip(name, state, frames.Length > 0 ? frames : idle, fps, loop));
        }
        ov.ApplyOverrides(pairs);
        EditorUtility.SetDirty(ov);
    }

    static Sprite[] Frames(string name, string state) =>
        Directory.GetFiles($"{SpriteRoot}/{name}", state.ToLower() + "_*.png")
            .OrderBy(f => int.Parse(Path.GetFileNameWithoutExtension(f).Split('_')[1]))
            .Select(f => AssetDatabase.LoadAssetAtPath<Sprite>(f.Replace('\\', '/')))
            .Where(s => s)
            .ToArray();

    static AnimationClip Clip(string name, string state, Sprite[] frames, float fps, bool loop)
    {
        string path = $"{OutRoot}/{name}_{state}.anim";
        var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
        if (!clip)
        {
            clip = new AnimationClip();
            AssetDatabase.CreateAsset(clip, path);
        }
        clip.frameRate = fps;
        // Last key repeats the last frame so every frame gets the same screen time.
        var keys = frames.Select((s, i) => new ObjectReferenceKeyframe { time = i / fps, value = s })
            .Append(new ObjectReferenceKeyframe { time = frames.Length / fps, value = frames[^1] }).ToArray();
        AnimationUtility.SetObjectReferenceCurve(clip, EditorCurveBinding.PPtrCurve("", typeof(SpriteRenderer), "m_Sprite"), keys);
        var settings = AnimationUtility.GetAnimationClipSettings(clip);
        settings.loopTime = loop;
        AnimationUtility.SetAnimationClipSettings(clip, settings);
        EditorUtility.SetDirty(clip);
        return clip;
    }
}
