using UnityEditor;
using UnityEngine;

// Every texture in Assets follows asset-spec.md: PPU 32, Point, no compression.
// Pivot at the feet (bottom-center), except tiles and projectiles, which are centered.
public class PixelArtImporter : AssetPostprocessor
{
    public override uint GetVersion() => 2;

    void OnPreprocessTexture()
    {
        if (!assetPath.StartsWith("Assets/")) return;
        var ti = (TextureImporter)assetImporter;
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 32;
        ti.filterMode = FilterMode.Point;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
        ti.mipmapEnabled = false;
        var s = new TextureImporterSettings();
        ti.ReadTextureSettings(s);
        bool centered = assetPath.Contains("/Tiles/") || assetPath.Contains("/Projectiles/");
        s.spriteAlignment = (int)(centered ? SpriteAlignment.Center : SpriteAlignment.BottomCenter);
        s.spriteMeshType = SpriteMeshType.FullRect;
        ti.SetTextureSettings(s);
    }
}
