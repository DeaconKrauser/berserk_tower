using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

// A built tower. Attack towers fire projectiles; support towers (aura) act through Game's aura queries.
public class Tower : MonoBehaviour
{
    public TowerData data;
    public int level = 1, invested;
    public TowerStats stats;   // current level, without aura buffs

    public TowerUpgradeData NextUpgrade => level - 1 < data.upgrades.Count ? data.upgrades[level - 1] : null;
    public int MaxLevel => data.upgrades.Count + 1;
    public int SellValue => Mathf.FloorToInt(invested * Game.I.level.sellRefund);
    public bool IsSupport => stats.auraRadius > 0;
    public string LevelName => level == 1 ? "" : data.upgrades[level - 2].displayName;
    public Vector2 Pos => transform.position;

    SpriteRenderer body, range, ring;
    SpriteRenderer[] pips;
    Light2D glow;
    float cooldown = 0.3f;
    readonly List<Enemy> targets = new();

    public void Init(TowerData d, Vector2 at)
    {
        data = d;
        stats = d.stats;
        invested = d.cost;
        transform.position = at;
        body = Gfx.Renderer(transform, "Body", d.sprite, Vector2.zero, Gfx.OrderWorld);
        Gfx.Shadow(transform, d.footprintRadius * 2.3f);
        int w = Mathf.RoundToInt(d.footprintRadius * 2.6f * Gfx.PPU);
        ring = Gfx.Renderer(transform, "Ring", Gfx.Ellipse(w, w / 3, new Color32(242, 163, 58, 30), new Color32(242, 163, 58, 255)), Vector2.zero, Gfx.OrderOverlay + 1);
        range = Gfx.Renderer(transform, "Range", null, Vector2.zero, Gfx.OrderOverlay);
        ring.enabled = range.enabled = false;
        pips = new SpriteRenderer[MaxLevel];
        for (int i = 0; i < MaxLevel; i++)
            pips[i] = Gfx.Renderer(transform, "Pip", Gfx.Pip, new Vector2((i - (MaxLevel - 1) / 2f) * 0.2f, -0.32f), Gfx.OrderBars);
        if (d.lightRadius > 0)
        {
            glow = Gfx.Light(transform, new Vector2(0, d.muzzleHeight * 0.7f), d.lightColor, d.lightRadius, 0.9f);
            glow.gameObject.AddComponent<Flicker>();
        }
        RefreshPips();
    }

    public void Upgrade()
    {
        var u = NextUpgrade;
        invested += u.cost;
        stats = u.stats;
        level++;
        if (u.sprite) body.sprite = u.sprite;
        if (glow) glow.pointLightOuterRadius = data.lightRadius * (1 + 0.15f * (level - 1));
        RefreshPips();
    }

    void RefreshPips()
    {
        for (int i = 0; i < pips.Length; i++)
            pips[i].color = i < level ? new Color32(242, 163, 58, 255) : new Color32(60, 56, 64, 255);
    }

    public void SetSelected(bool on) => ring.enabled = range.enabled = on;

    // Stats after War Chapel auras (strongest chapel in range wins; they don't stack).
    public TowerStats Effective(out float damageBonus, out float speedBonus, out float rangeBonus)
    {
        damageBonus = speedBonus = rangeBonus = 0;
        foreach (var t in Game.I.towers)
            if (t != this && t.IsSupport && Vector2.Distance(t.Pos, Pos) <= t.stats.auraRadius)
            {
                damageBonus = Mathf.Max(damageBonus, t.stats.auraDamageBonus);
                speedBonus = Mathf.Max(speedBonus, t.stats.auraAttackSpeedBonus);
                rangeBonus = Mathf.Max(rangeBonus, t.stats.auraRangeBonus);
            }
        var s = stats;
        if (IsSupport) return s;
        s.damage *= 1 + damageBonus;
        s.burnDps *= 1 + damageBonus;
        s.attackInterval /= 1 + speedBonus;
        s.range *= 1 + rangeBonus;
        return s;
    }

    public TowerStats Effective() => Effective(out _, out _, out _);

    public bool Contains(Vector2 p) =>
        Mathf.Abs(p.x - Pos.x) < data.footprintRadius + 0.15f && p.y > Pos.y - data.footprintRadius * 0.7f &&
        p.y < Pos.y + body.sprite.bounds.size.y;

    void Update()
    {
        if (range.enabled)
        {
            bool aura = IsSupport;
            range.sprite = Gfx.Circle(aura ? stats.auraRadius : Effective().range,
                aura ? new Color32(168, 137, 74, 26) : new Color32(232, 220, 192, 18),
                aura ? new Color32(210, 170, 90, 200) : new Color32(232, 220, 192, 150));
        }
        if (IsSupport || Game.I.over || (cooldown -= Time.deltaTime) > 0) return;

        var s = Effective();
        targets.Clear();
        foreach (var e in Game.I.enemies)
            if (Vector2.Distance(e.transform.position, Pos) <= s.range) targets.Add(e);
        if (targets.Count == 0) return;
        if (data.targeting == TargetPriority.Strongest) targets.Sort((a, b) => b.hp.CompareTo(a.hp));
        else targets.Sort((a, b) => b.progress.CompareTo(a.progress));

        cooldown = s.attackInterval;
        var muzzle = Pos + Vector2.up * data.muzzleHeight;
        for (int i = 0; i < Mathf.Min(Mathf.Max(1, s.targets), targets.Count); i++)
            Projectile.Fire(data.projectile, muzzle, targets[i], s, data.displayName);
    }
}
