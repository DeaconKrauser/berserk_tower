using System.Collections.Generic;
using UnityEngine;

// Entry point of the level's tunable data: economy, build menu, wave list and the commander.
[CreateAssetMenu(menuName = "Bastião/Fase")]
public class LevelData : ScriptableObject
{
    [Header("Economia")]
    public int startingGold;
    public int lives;
    [Tooltip("Ouro ao vencer uma onda = base + porOnda × número da onda")]
    public int waveClearBonus;
    public int waveClearBonusPerWave;
    [Range(0, 1)] public float sellRefund = 0.7f;
    [Tooltip("Fração mínima do dano físico que atravessa qualquer armadura")]
    [Range(0, 1)] public float minPhysicalDamage = 0.15f;

    [Header("Conteúdo")]
    public List<TowerData> towers = new();
    public List<WaveData> waves = new();

    [Header("Comandante")]
    public RuntimeAnimatorController commanderFront;
    public RuntimeAnimatorController commanderBack;
    public float commanderHp;
    public float commanderDamage;
    public float commanderArmorPenetration;
    [Tooltip("Segundos entre golpes")] public float commanderAttackInterval;
    public float commanderReach;
    [Tooltip("Inimigos atingidos por golpe")] public int commanderCleave;
    [Tooltip("Inimigos comuns que ele segura ao mesmo tempo (chefes sempre param)")] public int commanderBlockCount;
    public float commanderSpeed;
}
