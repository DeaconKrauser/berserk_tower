using UnityEngine;

[CreateAssetMenu(menuName = "Bastião/Inimigo")]
public class EnemyData : ScriptableObject
{
    public string displayName;
    [Tooltip("Override do Character.controller (Idle/Walk/Attack/Hit/Death)")]
    public RuntimeAnimatorController animator;

    [Header("Defesa")]
    public float maxHp;
    [Tooltip("Redução fixa de dano físico por golpe")] public float armor;
    [Tooltip("-0.5 = fraqueza, 0.5 = resiste metade")] [Range(-1, 1)] public float physicalResistance;
    [Range(-1, 1)] public float fireResistance;

    [Header("Movimento")]
    [Tooltip("Unidades por segundo")] public float speed;
    [Tooltip("Raio do corpo: separação na estrada e bloqueio de construção")] public float bodyRadius = 0.3f;

    [Header("Recompensa e custo")]
    public int bounty;
    [Tooltip("Vidas perdidas ao alcançar a fortaleza")] public int livesCost = 1;

    [Header("Combate contra o comandante")]
    public float attackDamage;
    public float attackInterval = 1f;

    [Header("Chefe")]
    public bool isBoss;
    public EnemyData summon;
    public int summonCount;
    public float summonInterval;
    [Tooltip("Enfurece abaixo desta fração de HP (0 = nunca)")] [Range(0, 1)] public float enrageBelowHp;
    public float enrageSpeedMultiplier = 1f;

    [Header("Luz própria (opcional)")]
    public Color lightColor = Color.white;
    public float lightRadius;
}
