using System.Collections.Generic;
using UnityEngine;

// Sub-wave: groups run in order; each waits its delay, then spawns count units every interval seconds.
[System.Serializable]
public class SpawnGroup
{
    public EnemyData enemy;
    public int count = 1;
    [Tooltip("Segundos entre unidades do grupo")] public float interval = 1f;
    [Tooltip("Segundos de espera antes do grupo começar")] public float delay;
}

[CreateAssetMenu(menuName = "Bastião/Onda")]
public class WaveData : ScriptableObject
{
    public string title;
    public List<SpawnGroup> groups = new();
}
