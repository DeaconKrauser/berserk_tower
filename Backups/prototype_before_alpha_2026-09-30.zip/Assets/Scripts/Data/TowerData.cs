using System.Collections.Generic;
using UnityEngine;

public enum DamageType { Physical, Fire }
public enum TargetPriority { First, Strongest }

// Full stat block of one tower level. Attack towers use the first group, support towers the aura group.
[System.Serializable]
public struct TowerStats
{
    [Header("Ataque")]
    public float damage;
    public DamageType damageType;
    [Tooltip("Segundos entre ataques")] public float attackInterval;
    public float range;
    [Tooltip("Armadura ignorada por golpe")] public float armorPenetration;
    [Tooltip("Raio de dano em área; 0 = alvo único")] public float splashRadius;
    [Tooltip("Alvos por ataque")] public int targets;
    [Tooltip("Dano de fogo por segundo após o impacto")] public float burnDps;
    public float burnDuration;

    [Header("Suporte (aura)")]
    public float auraRadius;
    [Tooltip("+% de dano para torres na aura")] public float auraDamageBonus;
    [Tooltip("+% de velocidade de ataque para torres na aura")] public float auraAttackSpeedBonus;
    [Tooltip("+% de alcance para torres na aura")] public float auraRangeBonus;
    [Tooltip("Armadura removida de inimigos dentro da aura")] public float auraArmorShred;
    [Tooltip("HP/s para o comandante dentro da aura")] public float commanderHealPerSecond;
}

[CreateAssetMenu(menuName = "Bastião/Torre")]
public class TowerData : ScriptableObject
{
    public string displayName;
    [Tooltip("Uma linha: papel da torre")] public string role;
    public int cost;
    public Sprite sprite;
    [Tooltip("Raio ocupado no chão (unidades)")] public float footprintRadius = 0.65f;
    [Tooltip("Altura de onde saem os projéteis (unidades)")] public float muzzleHeight = 1.8f;
    public TargetPriority targeting;
    public ProjectileData projectile;
    public Color lightColor = Color.white;
    [Tooltip("0 = sem luz")] public float lightRadius;
    [Tooltip("Nível 1")] public TowerStats stats;
    [Tooltip("Níveis 2, 3 e 4")] public List<TowerUpgradeData> upgrades = new();
}
