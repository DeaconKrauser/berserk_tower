using UnityEngine;

[CreateAssetMenu(menuName = "Bastião/Projétil")]
public class ProjectileData : ScriptableObject
{
    public Sprite sprite;
    [Tooltip("Unidades por segundo")] public float speed = 12f;
    [Tooltip("Altura do arco em unidades; 0 = trajetória reta")] public float arcHeight;
    [Tooltip("Persegue o alvo; senão cai no ponto previsto (bom para área)")] public bool homing = true;
    public Color impactColor = Color.white;
}
