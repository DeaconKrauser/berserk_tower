using UnityEngine;

// One upgrade step. Holds the complete stats of the new level (not multipliers), so each tower evolves its own way.
[CreateAssetMenu(menuName = "Bastião/Melhoria de Torre")]
public class TowerUpgradeData : ScriptableObject
{
    public string displayName;
    [TextArea] public string description;
    public int cost;
    [Tooltip("Opcional: troca o sprite da torre neste nível")] public Sprite sprite;
    public TowerStats stats;
}
