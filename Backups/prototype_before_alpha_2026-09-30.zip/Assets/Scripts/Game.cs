using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

// Match state and flow: economy, waves/sub-waves, free tower placement, selection and input.
// All balance lives in LevelData and the assets it references (Assets/Data, Assets/Resources/Level01).
public class Game : MonoBehaviour
{
    public static Game I;
    public static bool Automated;       // smoke test: ignore real mouse/keyboard

    public LevelData level;
    public Map map;
    public Commander commander;
    public Hud hud;
    public readonly List<Enemy> enemies = new();
    public readonly List<Tower> towers = new();

    public int gold, lives, wave, group, groupCount;
    public int kills, leaks, summoned;
    public readonly Dictionary<string, float> damageBySource = new(), bossDamageBySource = new();
    public bool waveRunning, spawning, over, victory, paused;
    public float speed = 1;
    public string endReason;

    public TowerData building;          // tower chosen in the build menu, placing
    public Tower selected;
    public bool commanderSelected;
    public string buildHint;            // shown next to the cursor
    public bool buildOk;
    public Vector2? previewAt;          // smoke test drives the ghost without a mouse

    BuildGhost ghost;

    public WaveData NextWave => wave < level.waves.Count ? level.waves[wave] : null;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Hook() => SceneManager.sceneLoaded += (_, _) => new GameObject("Game").AddComponent<Game>();

    void Awake()
    {
        I = this;
        Time.timeScale = 1;
        level = Resources.Load<LevelData>("Level01");
        gold = level.startingGold;
        lives = level.lives;
        SetupCamera();
        map = new GameObject("Map").AddComponent<Map>();
        commander = new GameObject("Commander").AddComponent<Commander>();
        commander.Init(level, Map.CommanderStart);
        ghost = new GameObject("BuildGhost").AddComponent<BuildGhost>();
        hud = new GameObject("Hud").AddComponent<Hud>();
    }

    static void SetupCamera()
    {
        var cam = Camera.main;
        cam.orthographic = true;
        cam.transform.position = new Vector3(0, 0, -10);
        cam.backgroundColor = new Color32(11, 10, 13, 255);
        var ppc = cam.GetComponent<PixelPerfectCamera>();
        if (!ppc) ppc = cam.gameObject.AddComponent<PixelPerfectCamera>();
        ppc.assetsPPU = Gfx.PPU;
        ppc.refResolutionX = 960;
        ppc.refResolutionY = 540;
        ppc.gridSnapping = PixelPerfectCamera.GridSnapping.UpscaleRenderTexture;
        ppc.cropFrame = PixelPerfectCamera.CropFrame.StretchFill;
        foreach (var l in FindObjectsByType<Light2D>())
            if (l.lightType == Light2D.LightType.Global)
            {
                l.intensity = 0.72f;
                l.color = new Color(0.8f, 0.82f, 1f);
            }
    }

    void Update()
    {
        HandleKeys();
        if (over)
        {
            ghost.Hide();
            buildHint = null;
            return;
        }
        HandlePointer();
        if (waveRunning && !spawning && enemies.Count == 0) ClearWave();
    }

    // ---------------------------------------------------------------- input

    void HandleKeys()
    {
        var k = Keyboard.current;
        if (k == null || Automated) return;
        if (k.escapeKey.wasPressedThisFrame)
        {
            if (building) building = null;
            else Select(null);
        }
        if (over) return;
        for (int i = 0; i < level.towers.Count && i < 9; i++)
            if (k[Key.Digit1 + i].wasPressedThisFrame) ToggleBuild(level.towers[i]);
        if (k.spaceKey.wasPressedThisFrame) StartWave();
        if (k.uKey.wasPressedThisFrame && selected) TryUpgrade(selected);
        if ((k.deleteKey.wasPressedThisFrame || k.backspaceKey.wasPressedThisFrame) && selected) Sell(selected);
        if (k.pKey.wasPressedThisFrame) TogglePause();
        if (k.fKey.wasPressedThisFrame) ToggleSpeed();
    }

    void HandlePointer()
    {
        var mouse = Mouse.current;
        Vector2 world = previewAt ?? ScreenToWorld(mouse);
        world = new Vector2(Mathf.Round(world.x * Gfx.PPU) / Gfx.PPU, Mathf.Round(world.y * Gfx.PPU) / Gfx.PPU);
        bool overUi = previewAt == null && EventSystem.current && EventSystem.current.IsPointerOverGameObject();

        buildHint = null;
        if (building && !overUi)
        {
            bool ok = buildOk = CanBuild(building, world, out var reason);
            ghost.Show(building, world, ok);
            buildHint = ok ? $"{building.displayName} · {building.cost} de ouro" : reason;
        }
        else ghost.Hide();

        if (Automated || mouse == null || overUi) return;
        if (mouse.leftButton.wasPressedThisFrame) LeftClick(world);
        else if (mouse.rightButton.wasPressedThisFrame)
        {
            if (building) building = null;
            else commander.MoveTo(world);
        }
    }

    static Vector2 ScreenToWorld(Mouse mouse)
    {
        if (mouse == null) return Vector2.zero;
        var p = mouse.position.ReadValue();
        return Camera.main.ViewportToWorldPoint(new Vector3(p.x / Screen.width, p.y / Screen.height, 10));
    }

    void LeftClick(Vector2 p)
    {
        if (building)
        {
            bool keep = Keyboard.current != null && Keyboard.current.shiftKey.isPressed;
            if (TryBuild(building, p) && !keep) building = null;
            return;
        }
        if (commander.Alive && commander.Hit(p)) { SelectCommander(); return; }
        var t = TowerAt(p);
        if (t) { Select(t); return; }
        if (commanderSelected) { commander.MoveTo(p); return; }
        Select(null);
    }

    Tower TowerAt(Vector2 p)
    {
        Tower best = null;
        foreach (var t in towers)
            if (t.Contains(p) && (!best || t.Pos.y < best.Pos.y)) best = t;
        return best;
    }

    public void Select(Tower t)
    {
        if (selected) selected.SetSelected(false);
        selected = t;
        commanderSelected = false;
        if (t)
        {
            building = null;
            t.SetSelected(true);
        }
    }

    public void SelectCommander()
    {
        Select(null);
        building = null;
        commanderSelected = commander.Alive;
    }

    public void ToggleBuild(TowerData t)
    {
        if (over) return;
        building = building == t ? null : t;
        if (building) Select(null);
    }

    public void TogglePause() { paused = !paused; ApplyTime(); }
    public void ToggleSpeed() { speed = speed > 1 ? 1 : 2; ApplyTime(); }
    public void SetSpeed(float s) { speed = s; ApplyTime(); }
    void ApplyTime() => Time.timeScale = paused ? 0 : speed;

    public void Restart() => SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    // ---------------------------------------------------------------- building

    public bool CanBuild(TowerData t, Vector2 p, out string reason, bool ignoreGold = false)
    {
        float r = t.footprintRadius;
        reason = null;
        if (!Map.BuildArea.Contains(p)) reason = "Fora da área de construção";
        else if (map.DistanceToRoad(p) < Map.RoadHalfWidth + r) reason = "Não se constrói sobre a estrada";
        else if (map.Blocked(p, r, out var zone)) reason = zone;
        else if (towers.Exists(o => Vector2.Distance(o.Pos, p) < r + o.data.footprintRadius)) reason = "Espaço ocupado por outra torre";
        else if (Vector2.Distance(commander.transform.position, p) < r + 0.35f) reason = "O comandante está no lugar";
        else if (enemies.Exists(e => Vector2.Distance(e.transform.position, p) < r + e.data.bodyRadius)) reason = "Há inimigos no lugar";
        else if (!ignoreGold && gold < t.cost) reason = "Ouro insuficiente";
        return reason == null;
    }

    public Tower TryBuild(TowerData t, Vector2 p)
    {
        if (!CanBuild(t, p, out _)) return null;
        gold -= t.cost;
        var tower = new GameObject(t.displayName).AddComponent<Tower>();
        tower.Init(t, p);
        towers.Add(tower);
        return tower;
    }

    public bool TryUpgrade(Tower t)
    {
        var next = t.NextUpgrade;
        if (over || !next || gold < next.cost) return false;
        gold -= next.cost;
        t.Upgrade();
        return true;
    }

    public void Sell(Tower t)
    {
        if (over) return;
        gold += t.SellValue;
        towers.Remove(t);
        if (selected == t) Select(null);
        Destroy(t.gameObject);
    }

    // War Chapel auras, queried by enemies (armor) and the commander (healing).
    public float ArmorShredAt(Vector2 p)
    {
        float s = 0;
        foreach (var t in towers)
            if (t.IsSupport && Vector2.Distance(t.Pos, p) <= t.stats.auraRadius) s = Mathf.Max(s, t.stats.auraArmorShred);
        return s;
    }

    public float CommanderHealAt(Vector2 p)
    {
        float h = 0;
        foreach (var t in towers)
            if (t.IsSupport && Vector2.Distance(t.Pos, p) <= t.stats.auraRadius) h = Mathf.Max(h, t.stats.commanderHealPerSecond);
        return h;
    }

    // ---------------------------------------------------------------- waves

    public void StartWave()
    {
        if (over || waveRunning || !NextWave) return;
        var w = NextWave;
        wave++;
        waveRunning = spawning = true;
        group = 0;
        groupCount = w.groups.Count;
        hud.Banner($"Onda {wave} · {w.title}");
        StartCoroutine(RunWave(w));
    }

    IEnumerator RunWave(WaveData w)
    {
        for (int i = 0; i < w.groups.Count; i++)
        {
            var g = w.groups[i];
            group = i + 1;
            if (g.delay > 0) yield return new WaitForSeconds(g.delay);
            for (int n = 0; n < g.count; n++)
            {
                Spawn(g.enemy, 0, Random.Range(-0.45f, 0.45f));
                if (n < g.count - 1) yield return new WaitForSeconds(g.interval);
            }
        }
        spawning = false;
    }

    public Enemy Spawn(EnemyData d, float progress, float lane)
    {
        var e = new GameObject(d.displayName).AddComponent<Enemy>();
        e.Init(d, Mathf.Clamp(progress, 0, map.Length - 1), lane);
        enemies.Add(e);
        return e;
    }

    void ClearWave()
    {
        waveRunning = false;
        int bonus = level.waveClearBonus + level.waveClearBonusPerWave * wave;
        gold += bonus;
        commander.HealFull();
        if (!NextWave) End(true, "O Cavaleiro Amaldiçoado caiu. O bastião resiste, por enquanto.");
        else hud.Banner($"Onda {wave} vencida · +{bonus} de ouro");
    }

    public void Killed(Enemy e)
    {
        enemies.Remove(e);
        commander.Release(e);
        gold += e.data.bounty;
        kills++;
    }

    public void Leak(Enemy e)
    {
        enemies.Remove(e);
        commander.Release(e);
        leaks++;
        lives = Mathf.Max(0, lives - e.data.livesCost);
        if (lives == 0) End(false, $"{e.data.displayName} atravessou os portões. A fortaleza caiu.");
    }

    public void Defeat(string why) => End(false, why);

    public void RecordDamage(string source, float dealt, bool boss)
    {
        damageBySource[source] = damageBySource.GetValueOrDefault(source) + dealt;
        if (boss) bossDamageBySource[source] = bossDamageBySource.GetValueOrDefault(source) + dealt;
    }

    void End(bool won, string why)
    {
        if (over) return;
        over = true;
        victory = won;
        endReason = why;
        building = null;
        StopAllCoroutines();
    }
}
