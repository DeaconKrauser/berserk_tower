using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Tilemaps;

// Level layout (geometry, not balance): the road, build limits, no-build zones and the provisional dressing.
// View is 30 x 16.9 units (960x540 at 32 PPU); the HUD covers the top-right and bottom corners.
public class Map : MonoBehaviour
{
    public static readonly Vector2[] Waypoints =
    {
        new(-16f, 2.2f), new(-4f, 2.2f), new(-4f, -1.6f), new(-10f, -1.6f),
        new(-10f, -5.2f), new(6f, -5.2f), new(6f, -0.6f), new(11.4f, -0.6f),
    };
    public const float RoadHalfWidth = 0.8f;
    public static readonly Rect BuildArea = Rect.MinMaxRect(-14.3f, -6.3f, 14.3f, 4.6f);
    static readonly Rect WalkArea = Rect.MinMaxRect(-14.5f, -6.3f, 14.5f, 5f);
    public static readonly Vector2 CommanderStart = new(0.5f, -4.8f);
    public static Vector2 Fortress => Waypoints[^1];

    public struct Zone
    {
        public Vector2 center;
        public float radius;
        public string reason;
        public bool cursed;   // drawn as cursed ground
        public Zone(float x, float y, float r, string why, bool cursedGround = true) { center = new(x, y); radius = r; reason = why; cursed = cursedGround; }
    }

    public readonly List<Zone> noBuild = new()
    {
        new(-14.4f, 2.2f, 1.8f, "Portão dos mortos: não se constrói aqui", false),
        new(-12.7f, -0.3f, 1.4f, "Cemitério: solo profanado"),
        new(1.0f, 1.9f, 1.3f, "Ruínas: terreno instável"),
        new(10.4f, -4.3f, 1.2f, "Fosso de corrupção"),
        new(11.4f, 1.4f, 2.1f, "Muralhas da fortaleza", false),
        new(11.4f, 4.2f, 1.5f, "Muralhas da fortaleza", false),
    };
    readonly List<(Vector2 at, float radius)> props = new();

    const float Step = 0.05f;
    Vector2[] pts, nrm;
    public float Length { get; private set; }

    void Awake()
    {
        BuildPath();
        BuildTiles();
        BuildProps();
    }

    // ---------------------------------------------------------------- route

    void BuildPath()
    {
        // Corners become quadratic curves so lateral lane offsets never jump.
        var raw = new List<Vector2> { Waypoints[0] };
        for (int i = 1; i < Waypoints.Length - 1; i++)
        {
            Vector2 a = Waypoints[i - 1], w = Waypoints[i], b = Waypoints[i + 1];
            float r = Mathf.Min(1.1f, Vector2.Distance(a, w) / 2, Vector2.Distance(w, b) / 2);
            Vector2 p0 = w + (a - w).normalized * r, p2 = w + (b - w).normalized * r;
            for (int k = 0; k <= 12; k++)
            {
                float t = k / 12f;
                raw.Add((1 - t) * (1 - t) * p0 + 2 * (1 - t) * t * w + t * t * p2);
            }
        }
        raw.Add(Waypoints[^1]);

        var cum = new float[raw.Count];
        for (int i = 1; i < raw.Count; i++) cum[i] = cum[i - 1] + Vector2.Distance(raw[i - 1], raw[i]);
        Length = cum[^1];
        int n = Mathf.CeilToInt(Length / Step) + 1, seg = 0;
        pts = new Vector2[n];
        for (int i = 0; i < n; i++)
        {
            float s = Mathf.Min(i * Step, Length);
            while (seg < raw.Count - 2 && cum[seg + 1] < s) seg++;
            float len = Mathf.Max(1e-5f, cum[seg + 1] - cum[seg]);
            pts[i] = Vector2.Lerp(raw[seg], raw[seg + 1], (s - cum[seg]) / len);
        }
        nrm = new Vector2[n];
        for (int i = 0; i < n; i++)
        {
            var tan = (pts[Mathf.Min(i + 1, n - 1)] - pts[Mathf.Max(i - 1, 0)]).normalized;
            nrm[i] = new Vector2(-tan.y, tan.x);
        }
    }

    // Point on the route at distance s, shifted sideways by lane (inside the road width).
    public Vector2 Position(float s, float lane)
    {
        float f = Mathf.Clamp(s, 0, Length) / Step;
        int i = Mathf.Min((int)f, pts.Length - 2);
        float t = f - i;
        return Vector2.Lerp(pts[i], pts[i + 1], t) + Vector2.Lerp(nrm[i], nrm[i + 1], t) * lane;
    }

    public float DistanceToRoad(Vector2 p)
    {
        float best = float.MaxValue;
        for (int i = 0; i < pts.Length - 1; i++)
        {
            Vector2 a = pts[i], ab = pts[i + 1] - a;
            float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / Mathf.Max(1e-6f, ab.sqrMagnitude));
            best = Mathf.Min(best, (a + ab * t - p).sqrMagnitude);
        }
        return Mathf.Sqrt(best);
    }

    public bool Blocked(Vector2 p, float radius, out string reason)
    {
        foreach (var z in noBuild)
            if (Vector2.Distance(p, z.center) < z.radius + radius * 0.5f) { reason = z.reason; return true; }
        foreach (var (at, r) in props)
            if (Vector2.Distance(p, at) < r + radius * 0.6f) { reason = "Obstáculo no terreno"; return true; }
        reason = null;
        return false;
    }

    public static Vector2 ClampWalk(Vector2 p) =>
        new(Mathf.Clamp(p.x, WalkArea.xMin, WalkArea.xMax), Mathf.Clamp(p.y, WalkArea.yMin, WalkArea.yMax));

    // ---------------------------------------------------------------- tilemap

    void BuildTiles()
    {
        var grid = new GameObject("Grid").AddComponent<Grid>();
        grid.transform.SetParent(transform, false);
        grid.cellSize = new Vector3(0.5f, 0.5f, 0);
        var ground = Layer(grid, "Ground", Gfx.OrderGround);
        var road = Layer(grid, "Road", Gfx.OrderGround + 1);
        var decals = Layer(grid, "Decals", Gfx.OrderDecal);

        var tiles = Resources.LoadAll<Sprite>("Map/Tiles")
            .GroupBy(s => s.name.Substring(0, s.name.LastIndexOf('_')))
            .ToDictionary(g => g.Key, g => g.Select(s => { var t = ScriptableObject.CreateInstance<Tile>(); t.sprite = s; return t; }).ToArray());
        var rnd = new System.Random(7);
        Tile Pick(string set) => tiles[set][rnd.Next(tiles[set].Length)];
        string[] scatter = { "grass", "grass", "stones", "stones", "bones", "crack", "blood", "skull" };

        for (int x = -32; x < 32; x++)
            for (int y = -18; y < 18; y++)
            {
                var cell = new Vector3Int(x, y, 0);
                var c = new Vector2((x + 0.5f) * 0.5f, (y + 0.5f) * 0.5f);
                float d = DistanceToRoad(c) + (Mathf.PerlinNoise(x * 0.37f + 11, y * 0.37f + 7) - 0.5f) * 0.45f;
                bool cursed = noBuild.Any(z => z.cursed && Vector2.Distance(c, z.center) < z.radius);
                bool plaza = Vector2.Distance(c, Fortress + new Vector2(0, -0.3f)) < 1.3f;
                ground.SetTile(cell, Pick(cursed ? "cursed" : "soil"));
                if (d < 0.42f || plaza) road.SetTile(cell, Pick("cobble"));
                else if (d < RoadHalfWidth) road.SetTile(cell, Pick("dirt"));
                else if (d < RoadHalfWidth + 0.45f) decals.SetTile(cell, Pick("grit"));
                else if (rnd.NextDouble() < (cursed ? 0.3 : 0.07)) decals.SetTile(cell, Pick(cursed ? (rnd.Next(2) == 0 ? "crack" : "bones") : scatter[rnd.Next(scatter.Length)]));
            }
    }

    static Tilemap Layer(Grid grid, string name, int order)
    {
        var go = new GameObject(name);
        go.transform.SetParent(grid.transform, false);
        var map = go.AddComponent<Tilemap>();
        go.AddComponent<TilemapRenderer>().sortingOrder = order;
        return map;
    }

    // ---------------------------------------------------------------- props

    void BuildProps()
    {
        // Fortress: its door is the end of the road.
        var fort = Prop("fortress", Fortress, block: false);
        Gfx.Light(fort.transform, new Vector2(0, 3.2f), new Color(1f, 0.2f, 0.18f), 3.6f, 0.9f);
        Torch(Fortress + new Vector2(-1.3f, -1.1f));
        Torch(Fortress + new Vector2(1.3f, -1.1f));
        Prop("banner_raven", new Vector2(9.1f, 0.7f));
        Prop("banner_raven", new Vector2(13.7f, 0.7f), flip: true);

        // Gate of the dead, where they come from.
        Prop("ruin_1", new Vector2(-14.3f, 3.3f));
        Prop("ruin_2", new Vector2(-13.8f, 0.9f));
        Prop("banner_skull", new Vector2(-12.3f, 3.4f));
        Torch(new Vector2(-12.9f, 3.25f));
        Torch(new Vector2(-12.9f, 1.15f));

        // Graveyard.
        foreach (var (x, y, i) in new[] { (-13.6f, 0.4f, 0), (-12.7f, 0.5f, 1), (-11.8f, 0.2f, 2), (-13.3f, -0.8f, 1), (-12.3f, -0.9f, 0), (-11.6f, -1.1f, 2), (-13.7f, -1.5f, 0) })
            Prop($"tomb_{i}", new Vector2(x, y), blockRadius: 0.3f);
        Prop("deadtree_0", new Vector2(-14.0f, -1.9f));

        // Ruins in the middle of the field.
        Prop("ruin_0", new Vector2(0.6f, 2.1f));
        Prop("ruin_2", new Vector2(1.9f, 1.3f));
        Prop("rock_1", new Vector2(0.0f, 1.1f), blockRadius: 0.4f);

        // Corruption pit.
        var pit = Gfx.Renderer(transform, "Pit", Gfx.Ellipse(64, 30, new Color32(8, 4, 10, 230), new Color32(60, 24, 70, 255)), new Vector2(10.4f, -4.3f), Gfx.OrderDecal + 1);
        Gfx.Light(pit.transform, Vector2.zero, new Color(0.55f, 0.2f, 0.8f), 2.6f, 1f).gameObject.AddComponent<Flicker>();
        foreach (var (x, y) in new[] { (9.3f, -3.5f), (11.5f, -3.6f), (9.5f, -5.0f), (11.3f, -5.1f) })
            Prop("pike_0", new Vector2(x, y), blockRadius: 0.25f);

        // Torches along the road (inside the unbuildable margin).
        foreach (var p in new[] { new Vector2(-7f, 3.25f), new Vector2(-2.9f, 3.3f), new Vector2(-11.1f, -2.6f), new Vector2(-1f, -4.1f), new Vector2(7.1f, -6.2f), new Vector2(4.95f, -2.2f), new Vector2(8.5f, 0.45f) })
            Torch(p);

        // Map edges (outside the build area).
        Prop("deadtree_1", new Vector2(-9.2f, 5.2f));
        Prop("deadtree_0", new Vector2(3.6f, 5.4f));
        Prop("rock_0", new Vector2(-4.2f, 5.3f));
        Prop("rock_1", new Vector2(-12.4f, 5.0f));
        Prop("deadtree_1", new Vector2(14.6f, -2.2f));
        Prop("rock_0", new Vector2(14.4f, -5.6f));
        Prop("ruin_2", new Vector2(-14.2f, -4.6f));
    }

    SpriteRenderer Prop(string name, Vector2 at, bool block = true, float blockRadius = -1, bool flip = false)
    {
        var sprite = Resources.Load<Sprite>("Map/Props/" + name);
        var sr = Gfx.Renderer(transform, name, sprite, at, Gfx.OrderWorld);
        sr.flipX = flip;
        Gfx.Shadow(sr.transform, Mathf.Min(sprite.bounds.size.x * 0.8f, 3f));
        if (block) props.Add((at, blockRadius > 0 ? blockRadius : sprite.bounds.size.x * 0.4f));
        return sr;
    }

    void Torch(Vector2 at)
    {
        var t = Prop("torch_" + (Mathf.Abs(Mathf.RoundToInt(at.x * 7 + at.y)) % 2), at, blockRadius: 0.25f);
        Gfx.Light(t.transform, new Vector2(0, 1.7f), new Color(1f, 0.62f, 0.28f), 3.2f, 1.1f).gameObject.AddComponent<Flicker>();
    }
}
