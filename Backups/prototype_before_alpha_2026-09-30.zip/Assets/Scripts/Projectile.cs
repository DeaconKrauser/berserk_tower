using UnityEngine;

// Flies from the muzzle to the target (homing) or to its predicted ground point (lobbed, for area damage).
public class Projectile : MonoBehaviour
{
    ProjectileData data;
    TowerStats stats;
    string source;
    Enemy target;
    Vector2 from, to, last;
    float t, duration;

    public static void Fire(ProjectileData d, Vector2 from, Enemy target, TowerStats s, string source)
    {
        var p = new GameObject("Projectile").AddComponent<Projectile>();
        p.source = source;
        p.data = d;
        p.stats = s;
        p.target = target;
        p.from = p.last = from;
        p.duration = Mathf.Max(0.05f, Vector2.Distance(from, target.Center) / d.speed);
        p.to = d.homing ? target.Center : target.Predict(p.duration);
        p.transform.position = from;
        Gfx.Renderer(p.transform, "Sprite", d.sprite, Vector2.zero, Gfx.OrderProjectile);
    }

    void Update()
    {
        if (data.homing && target && target.Alive) to = target.Center;
        t += Time.deltaTime;
        float k = Mathf.Clamp01(t / duration);
        Vector2 pos = Vector2.Lerp(from, to, k) + Vector2.up * (data.arcHeight * 4 * k * (1 - k));
        if ((pos - last).sqrMagnitude > 1e-6f) transform.right = pos - last;
        transform.position = last = pos;
        if (k < 1) return;

        if (stats.splashRadius > 0)
        {
            var list = Game.I.enemies;
            for (int i = list.Count - 1; i >= 0; i--)
                if (i < list.Count && Vector2.Distance(list[i].transform.position, to) <= stats.splashRadius)
                    list[i].Hit(stats, source);
            Burst.Spawn(to, stats.splashRadius, data.impactColor);
        }
        else if (target && target.Alive) target.Hit(stats, source);
        Destroy(gameObject);
    }
}

// Short expanding ring so area damage reads on screen.
public class Burst : MonoBehaviour
{
    SpriteRenderer sr;
    float t;

    public static void Spawn(Vector2 at, float radius, Color color)
    {
        var b = new GameObject("Burst").AddComponent<Burst>();
        b.transform.position = at;
        b.sr = Gfx.Renderer(b.transform, "Ring", Gfx.Circle(radius, new Color(color.r, color.g, color.b, 0.3f), color), Vector2.zero, Gfx.OrderProjectile);
    }

    void Update()
    {
        t += Time.deltaTime / 0.3f;
        transform.localScale = Vector3.one * Mathf.Lerp(0.5f, 1f, t);
        sr.color = new Color(1, 1, 1, 1 - t);
        if (t >= 1) Destroy(gameObject);
    }
}
