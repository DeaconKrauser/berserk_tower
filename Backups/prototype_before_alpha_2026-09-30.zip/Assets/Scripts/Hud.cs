using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

// Screen-space HUD built from code (uGUI, 1920x1080 reference). Dark stone panels, ember accents.
public class Hud : MonoBehaviour
{
    static readonly Color Bone = new Color32(232, 220, 192, 255), Ember = new Color32(242, 163, 58, 255),
        Dim = new Color32(150, 146, 140, 255), Gold = new Color32(200, 168, 96, 255), Bad = new Color32(255, 96, 84, 255);

    Game g;
    Font font;
    Sprite panelSprite, buttonSprite;
    RectTransform root, towerPanel, tip;
    Text stats, waveInfo, nextWave, banner, tipText, cmdHp, pausedText;
    Text towerTitle, towerRole, towerLabels, towerValues, towerBuff, upgradeInfo, bossName, endTitle, endText;
    Text startLabel, speedLabel, pauseLabel, upgradeLabel, sellLabel;
    Button startButton, upgradeButton, sellButton;
    RectTransform cmdFill, bossFill;
    GameObject bossBar, endPanel;
    readonly List<(TowerData data, Button button, Image frame)> buildButtons = new();
    float bannerUntil;

    void Awake()
    {
        g = Game.I;
        font = Font.CreateDynamicFontFromOSFont(new[] { "Palatino Linotype", "Book Antiqua", "Georgia", "Times New Roman" }, 16);
        panelSprite = MakeSprite(new Color32(21, 19, 25, 238), new Color32(92, 78, 62, 255));
        buttonSprite = MakeSprite(new Color32(255, 255, 255, 255), new Color32(170, 150, 120, 255));
        if (!FindAnyObjectByType<EventSystem>())
            new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGo.transform.SetParent(transform, false);
        canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;
        root = (RectTransform)canvasGo.transform;

        BuildTopPanel();
        BuildCommanderPanel();
        BuildBuildBar();
        BuildTowerPanel();
        BuildBossBar();
        banner = Label(root, "Banner", new(0.5f, 1), new(0.5f, 1), new(0, -120), new(1500, 70), 44, TextAnchor.UpperCenter, Bone);
        pausedText = Label(root, "Paused", new(0.5f, 0.5f), new(0.5f, 0.5f), Vector2.zero, new(800, 90), 64, TextAnchor.MiddleCenter, Bone);
        pausedText.text = "PAUSADO";
        tip = Rect(root, "Tip", new(0, 0), new(0, 0), Vector2.zero, new(560, 40));
        tipText = Label(tip, "Text", new(0, 0.5f), new(0, 0.5f), new(28, 0), new(540, 40), 22, TextAnchor.MiddleLeft, Bone);
        BuildEndPanel();
    }

    // ---------------------------------------------------------------- layout

    void BuildTopPanel()
    {
        var p = Box(root, "Top", new(1, 1), new(1, 1), new(-16, -16), new(640, 204), panelSprite);
        stats = Label(p, "Stats", new(0, 1), new(0, 1), new(22, -12), new(600, 40), 32, TextAnchor.UpperLeft, Bone);
        waveInfo = Label(p, "Wave", new(0, 1), new(0, 1), new(22, -54), new(600, 32), 24, TextAnchor.UpperLeft, Bone);
        nextWave = Label(p, "Next", new(0, 1), new(0, 1), new(22, -88), new(600, 48), 17, TextAnchor.UpperLeft, Dim);
        (startButton, startLabel) = Btn(p, "Start", new(0, 0), new(0, 0), new(16, 14), new(344, 52), 23, g.StartWave);
        (_, speedLabel) = Btn(p, "Speed", new(0, 0), new(0, 0), new(370, 14), new(110, 52), 24, g.ToggleSpeed);
        (_, pauseLabel) = Btn(p, "Pause", new(0, 0), new(0, 0), new(490, 14), new(134, 52), 22, g.TogglePause);
    }

    void BuildCommanderPanel()
    {
        var p = Box(root, "Commander", new(0, 0), new(0, 0), new(16, 16), new(430, 118), panelSprite);
        p.gameObject.AddComponent<Button>().onClick.AddListener(() => { Deselect(); g.SelectCommander(); });
        Label(p, "Name", new(0, 1), new(0, 1), new(20, -10), new(390, 32), 27, TextAnchor.UpperLeft, Ember).text = "Comandante";
        var bg = Plain(p, "HpBg", new(0, 1), new(0, 1), new(20, -48), new(390, 22), new Color(0.05f, 0.04f, 0.06f));
        cmdFill = Plain(bg, "Fill", new(0, 0), new(0, 0), Vector2.zero, Vector2.zero, Gfx.CommanderHp);
        cmdFill.anchorMax = new Vector2(1, 1);
        cmdHp = Label(bg, "Hp", new(0.5f, 0.5f), new(0.5f, 0.5f), Vector2.zero, new(390, 22), 18, TextAnchor.MiddleCenter, Bone);
        Label(p, "Hint", new(0, 0), new(0, 0), new(20, 10), new(400, 40), 16, TextAnchor.LowerLeft, Dim).text =
            "Clique nele e depois no chão para mover.\nBotão direito também move.";
    }

    void BuildBuildBar()
    {
        const float w = 196, gap = 12;
        int n = g.level.towers.Count;
        var bar = Box(root, "BuildBar", new(0.5f, 0), new(0.5f, 0), new(0, 16), new(n * w + (n + 1) * gap, 150), panelSprite);
        for (int i = 0; i < n; i++)
        {
            var t = g.level.towers[i];
            var (b, _) = Btn(bar, t.displayName, new(0, 0.5f), new(0, 0.5f), new(gap + i * (w + gap), 0), new(w, 128), 18, () => g.ToggleBuild(t));
            var frame = Plain(b.transform, "Selected", new(0, 0), new(0, 0), Vector2.zero, Vector2.zero, new Color(0.95f, 0.64f, 0.23f, 0.35f));
            ((RectTransform)frame.transform).anchorMax = Vector2.one;
            var icon = Rect(b.transform, "Icon", new(0.5f, 1), new(0.5f, 1), new(0, -8), new(80, 72)).gameObject.AddComponent<Image>();
            icon.sprite = t.sprite;
            icon.preserveAspect = true;
            icon.raycastTarget = false;
            Label(b.transform, "Key", new(0, 1), new(0, 1), new(10, -6), new(30, 26), 20, TextAnchor.UpperLeft, Dim).text = (i + 1).ToString();
            Label(b.transform, "Name", new(0.5f, 0), new(0.5f, 0), new(0, 26), new(w - 10, 26), 19, TextAnchor.LowerCenter, Bone).text = t.displayName;
            Label(b.transform, "Cost", new(0.5f, 0), new(0.5f, 0), new(0, 5), new(w - 10, 24), 19, TextAnchor.LowerCenter, Ember).text = $"{t.cost} ouro";
            buildButtons.Add((t, b, frame.GetComponent<Image>()));
        }
    }

    void BuildTowerPanel()
    {
        towerPanel = Box(root, "TowerPanel", new(1, 0.5f), new(1, 0.5f), new(-16, -20), new(450, 690), panelSprite);
        towerTitle = Label(towerPanel, "Title", new(0, 1), new(0, 1), new(22, -14), new(410, 40), 31, TextAnchor.UpperLeft, Ember);
        towerRole = Label(towerPanel, "Role", new(0, 1), new(0, 1), new(22, -56), new(410, 76), 18, TextAnchor.UpperLeft, Dim);
        towerLabels = Label(towerPanel, "Labels", new(0, 1), new(0, 1), new(22, -138), new(230, 240), 21, TextAnchor.UpperLeft, Dim);
        towerValues = Label(towerPanel, "Values", new(0, 1), new(0, 1), new(200, -138), new(230, 240), 21, TextAnchor.UpperRight, Bone);
        towerBuff = Label(towerPanel, "Buff", new(0, 1), new(0, 1), new(22, -356), new(410, 50), 18, TextAnchor.UpperLeft, Gold);
        upgradeInfo = Label(towerPanel, "Upgrade", new(0, 1), new(0, 1), new(22, -406), new(410, 170), 18, TextAnchor.UpperLeft, Bone);
        (upgradeButton, upgradeLabel) = Btn(towerPanel, "UpgradeButton", new(0, 0), new(0, 0), new(16, 16), new(246, 56), 22, () => { if (g.selected) g.TryUpgrade(g.selected); });
        (sellButton, sellLabel) = Btn(towerPanel, "SellButton", new(1, 0), new(1, 0), new(-16, 16), new(164, 56), 21, () => { if (g.selected) g.Sell(g.selected); });
        towerPanel.gameObject.SetActive(false);
    }

    void BuildBossBar()
    {
        var p = Box(root, "Boss", new(0.5f, 1), new(0.5f, 1), new(-170, -16), new(680, 76), panelSprite);
        bossBar = p.gameObject;
        bossName = Label(p, "Name", new(0.5f, 1), new(0.5f, 1), new(0, -8), new(640, 30), 23, TextAnchor.UpperCenter, Bone);
        var bg = Plain(p, "Bg", new(0.5f, 0), new(0.5f, 0), new(0, 14), new(640, 20), new Color(0.05f, 0.04f, 0.06f));
        bossFill = Plain(bg, "Fill", new(0, 0), new(0, 0), Vector2.zero, Vector2.zero, new Color32(120, 40, 160, 255));
        bossFill.anchorMax = Vector2.one;
        bossBar.SetActive(false);
    }

    void BuildEndPanel()
    {
        var p = Box(root, "End", new(0.5f, 0.5f), new(0.5f, 0.5f), Vector2.zero, new(760, 320), panelSprite);
        endPanel = p.gameObject;
        endTitle = Label(p, "Title", new(0.5f, 1), new(0.5f, 1), new(0, -26), new(720, 80), 64, TextAnchor.UpperCenter, Ember);
        endText = Label(p, "Text", new(0.5f, 1), new(0.5f, 1), new(0, -118), new(680, 100), 24, TextAnchor.UpperCenter, Bone);
        Btn(p, "Restart", new(0.5f, 0), new(0.5f, 0), new(0, 26), new(320, 60), 26, g.Restart).label.text = "Jogar novamente";
        endPanel.SetActive(false);
    }

    // ---------------------------------------------------------------- per frame

    void Update()
    {
        stats.text = $"<color=#F2A33A>Ouro {g.gold}</color>      Vidas {g.lives}/{g.level.lives}";
        waveInfo.text = g.waveRunning
            ? $"Onda {g.wave}/{g.level.waves.Count}   ·   Grupo {g.group}/{g.groupCount}   ·   {g.enemies.Count} inimigos"
            : $"Onda {g.wave}/{g.level.waves.Count}   ·   preparação";
        nextWave.text = g.NextWave ? "Próxima: " + Composition(g.NextWave) : "Última onda.";
        startButton.interactable = !g.waveRunning && !g.over && g.NextWave;
        startLabel.text = g.waveRunning ? "Onda em andamento" : g.NextWave ? $"Iniciar onda {g.wave + 1}  [Espaço]" : "Fim";
        speedLabel.text = g.speed > 1 ? $"{g.speed:0}× [F]" : "1× [F]";
        pauseLabel.text = g.paused ? "Retomar" : "Pausar [P]";
        pausedText.enabled = g.paused;

        float f = g.commander.hp / g.commander.maxHp;
        cmdFill.anchorMax = new Vector2(f, 1);
        cmdFill.GetComponent<Image>().color = f < 0.3f ? Color.Lerp(Gfx.CommanderHp, Bad, Mathf.PingPong(Time.unscaledTime * 3, 1)) : Gfx.CommanderHp;
        cmdHp.text = $"{Mathf.CeilToInt(g.commander.hp)} / {g.commander.maxHp:0}";

        foreach (var (data, button, frame) in buildButtons)
        {
            button.interactable = !g.over && g.gold >= data.cost;
            frame.enabled = g.building == data;
        }

        UpdateTowerPanel();

        var boss = g.enemies.Find(e => e.data.isBoss);
        bossBar.SetActive(boss);
        if (boss)
        {
            bossName.text = boss.data.displayName + (boss.Enraged ? "  ·  ENFURECIDO" : "");
            bossFill.anchorMax = new Vector2(boss.hp / boss.data.maxHp, 1);
        }

        banner.color = new Color(Bone.r, Bone.g, Bone.b, Mathf.Clamp01((bannerUntil - Time.unscaledTime) / 0.6f));

        tip.gameObject.SetActive(g.buildHint != null && Mouse.current != null);
        if (tip.gameObject.activeSelf)
        {
            Vector2 at = g.previewAt.HasValue ? (Vector2)Camera.main.WorldToScreenPoint(g.previewAt.Value) : Mouse.current.position.ReadValue();
            RectTransformUtility.ScreenPointToLocalPointInRectangle(root, at, null, out var local);
            tip.anchoredPosition = local + root.rect.size / 2;
            tipText.text = g.buildHint;
            tipText.color = g.buildOk ? Bone : Bad;
        }

        endPanel.SetActive(g.over);
        if (g.over)
        {
            endTitle.text = g.victory ? "VITÓRIA" : "DERROTA";
            endTitle.color = g.victory ? Ember : Bad;
            endText.text = $"{g.endReason}\nOnda {g.wave}/{g.level.waves.Count} · {g.kills} inimigos abatidos · {g.lives} vidas";
        }
    }

    void UpdateTowerPanel()
    {
        var t = g.selected;
        towerPanel.gameObject.SetActive(t);
        if (!t) return;
        // Keep the panel on the side opposite to the tower.
        bool right = Camera.main.WorldToViewportPoint(t.Pos).x < 0.6f;
        towerPanel.anchorMin = towerPanel.anchorMax = towerPanel.pivot = new Vector2(right ? 1 : 0, 0.5f);
        towerPanel.anchoredPosition = new Vector2(right ? -16 : 16, -20);

        towerTitle.text = $"{t.data.displayName}  <size=22><color=#968C80>Nível {t.level}/{t.MaxLevel}</color></size>";
        towerRole.text = t.level > 1 ? $"<color=#C8A860>{t.LevelName}</color>\n{t.data.role}" : t.data.role;
        var eff = t.Effective(out float db, out float sb, out float rb);
        var lines = StatLines(t.data, eff);
        towerLabels.text = string.Join("\n", lines.Select(l => l.label));
        towerValues.text = string.Join("\n", lines.Select(l => l.value));
        towerBuff.text = db > 0 || sb > 0 || rb > 0
            ? $"Capela de Guerra: +{db * 100:0}% dano, +{sb * 100:0}% velocidade, +{rb * 100:0}% alcance"
            : t.IsSupport ? "Fortalece torres e cura o comandante dentro da aura." : "";

        var next = t.NextUpgrade;
        if (next)
        {
            upgradeInfo.text = $"<color=#F2A33A>Próximo: {next.displayName}</color>\n{next.description}\n<color=#968C80>{Diff(t.data, t.stats, next.stats)}</color>";
            upgradeLabel.text = $"Melhorar  {next.cost} [U]";
            upgradeButton.interactable = !g.over && g.gold >= next.cost;
        }
        else
        {
            upgradeInfo.text = "<color=#C8A860>Nível máximo.</color>";
            upgradeLabel.text = "Nível máximo";
            upgradeButton.interactable = false;
        }
        sellLabel.text = $"Vender +{t.SellValue}";
        sellButton.interactable = !g.over;
    }

    public void Banner(string text, float seconds = 3f)
    {
        banner.text = text;
        bannerUntil = Time.unscaledTime + seconds;
    }

    // ---------------------------------------------------------------- text helpers

    static string Composition(WaveData w) => string.Join("  ·  ",
        w.groups.GroupBy(x => x.enemy).Select(x => $"{x.Sum(s => s.count)}× {x.Key.displayName}"));

    static List<(string label, string value)> StatLines(TowerData d, TowerStats s)
    {
        var l = new List<(string, string)>();
        if (s.auraRadius > 0)
        {
            l.Add(("Raio da aura", $"{s.auraRadius:0.0}"));
            if (s.auraDamageBonus > 0) l.Add(("Dano das torres", $"+{s.auraDamageBonus * 100:0}%"));
            if (s.auraAttackSpeedBonus > 0) l.Add(("Vel. das torres", $"+{s.auraAttackSpeedBonus * 100:0}%"));
            if (s.auraRangeBonus > 0) l.Add(("Alcance das torres", $"+{s.auraRangeBonus * 100:0}%"));
            if (s.auraArmorShred > 0) l.Add(("Armadura inimiga", $"-{s.auraArmorShred:0}"));
            if (s.commanderHealPerSecond > 0) l.Add(("Cura do comandante", $"{s.commanderHealPerSecond:0} HP/s"));
            return l;
        }
        l.Add(("Dano", $"{s.damage:0} {(s.damageType == DamageType.Fire ? "fogo" : "físico")}"));
        l.Add(("Velocidade", $"{1 / s.attackInterval:0.00}/s"));
        l.Add(("Alcance", $"{s.range:0.0}"));
        if (s.armorPenetration > 0) l.Add(("Perfura armadura", $"{s.armorPenetration:0}"));
        if (s.splashRadius > 0) l.Add(("Área", $"{s.splashRadius:0.0}"));
        if (s.burnDps > 0) l.Add(("Queimadura", $"{s.burnDps:0}/s · {s.burnDuration:0.#}s"));
        if (s.targets > 1) l.Add(("Alvos por disparo", $"{s.targets}"));
        l.Add(("Prioridade", d.targeting == TargetPriority.Strongest ? "mais resistente" : "mais avançado"));
        return l;
    }

    static string Diff(TowerData d, TowerStats now, TowerStats next)
    {
        var before = StatLines(d, now).ToDictionary(x => x.label, x => x.value);
        var parts = new List<string>();
        foreach (var (label, value) in StatLines(d, next))
            if (!before.TryGetValue(label, out var old)) parts.Add($"{label}: {value} (novo)");
            else if (old != value) parts.Add($"{label} {old} → {value}");
        return string.Join("\n", parts);
    }

    // ---------------------------------------------------------------- uGUI factory

    static Sprite MakeSprite(Color32 fill, Color32 rim)
    {
        const int n = 12;
        var t = new Texture2D(n, n) { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
        var px = new Color32[n * n];
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++)
            {
                int e = Mathf.Min(Mathf.Min(x, y), Mathf.Min(n - 1 - x, n - 1 - y));
                px[y * n + x] = e == 0 ? new Color32(8, 7, 10, 255) : e == 1 ? rim : e == 2 ? new Color32(8, 7, 10, 200) : fill;
            }
        t.SetPixels32(px);
        t.Apply();
        return Sprite.Create(t, new UnityEngine.Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100, 0, SpriteMeshType.FullRect, new Vector4(4, 4, 4, 4));
    }

    static RectTransform Rect(Transform parent, string name, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        var rt = (RectTransform)new GameObject(name, typeof(RectTransform)).transform;
        rt.SetParent(parent, false);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = pivot;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    static RectTransform Box(Transform parent, string name, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size, Sprite sprite)
    {
        var rt = Rect(parent, name, anchor, pivot, pos, size);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = sprite;
        img.type = Image.Type.Sliced;
        img.pixelsPerUnitMultiplier = 0.34f;
        return rt;
    }

    static RectTransform Plain(Transform parent, string name, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size, Color color)
    {
        var rt = Rect(parent, name, anchor, pivot, pos, size);
        var img = rt.gameObject.AddComponent<Image>();
        img.color = color;
        img.raycastTarget = false;
        return rt;
    }

    Text Label(Transform parent, string name, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size, int fontSize, TextAnchor align, Color color)
    {
        var t = Rect(parent, name, anchor, pivot, pos, size).gameObject.AddComponent<Text>();
        t.font = font;
        t.fontSize = fontSize;
        t.alignment = align;
        t.color = color;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        var shadow = t.gameObject.AddComponent<Shadow>();
        shadow.effectColor = new Color(0, 0, 0, 0.85f);
        shadow.effectDistance = new Vector2(2, -2);
        return t;
    }

    (Button button, Text label) Btn(Transform parent, string name, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size, int fontSize, Action onClick)
    {
        var rt = Box(parent, name, anchor, pivot, pos, size, buttonSprite);
        var b = rt.gameObject.AddComponent<Button>();
        var c = b.colors;
        c.normalColor = new Color32(62, 54, 52, 255);
        c.highlightedColor = new Color32(98, 78, 58, 255);
        c.pressedColor = new Color32(130, 94, 52, 255);
        c.selectedColor = c.normalColor;
        c.disabledColor = new Color32(38, 35, 40, 255);
        b.colors = c;
        b.navigation = new Navigation { mode = Navigation.Mode.None };
        b.onClick.AddListener(() =>
        {
            Deselect();   // otherwise Space would "submit" the last clicked button
            onClick();
        });
        var label = Label(rt, "Label", new(0.5f, 0.5f), new(0.5f, 0.5f), Vector2.zero, size, fontSize, TextAnchor.MiddleCenter, Bone);
        return (b, label);
    }

    static void Deselect()
    {
        if (EventSystem.current) EventSystem.current.SetSelectedGameObject(null);
    }
}
