using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;

// Player run with -smoketest: a scripted "reasonable player" plays all waves at 4x, logs balance data
// (lines start with SMOKE) and saves screenshots next to the executable data folder.
// Real mouse/keyboard are ignored so a person clicking the window can't change the run.
public class SmokeTest : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot()
    {
        if (System.Environment.GetCommandLineArgs().Contains("-smoketest"))
            new GameObject("SmokeTest").AddComponent<SmokeTest>();
    }

    // +X = build a tower of type X; ^Xn = upgrade the n-th tower of type X (A archer, B ballista, P pyre, C chapel).
    // Order of a player who reads the next-wave preview: archers early, ballistas before the knights, one ballista to max for the boss.
    readonly List<string> plan = new()
    {
        "+A", "+A", "+P", "^A0", "+B", "^P0", "+C", "^B0", "+B", "^A1", "^B0", "^C0", "+P", "^B1", "^P0", "^B0",
        "^C0", "^P1", "^B1", "^A0", "^C0", "^P0", "^B1", "+A", "^A1", "^P1", "^A2", "^P1", "^A0", "^A1", "^A2",
    };

    Game g;
    readonly List<Tower> built = new();
    readonly HashSet<string> shots = new();
    int errors, step;
    float cmdMinHp;
    Vector2 post;   // where the commander holds during the wave

    IEnumerator Start()
    {
        g = Game.I;
        Game.Automated = true;
        if (EventSystem.current) EventSystem.current.enabled = false;
        Application.logMessageReceived += (msg, stack, type) =>
        {
            if (type == LogType.Log || type == LogType.Warning || errors++ > 5) return;
            Debug.Log($"SMOKE error: {msg}\n{stack}");
        };
        g.SetSpeed(4);
        yield return null;
        yield return ShotWithGhost("smoke_prep_valid.png", g.level.towers[2], null);

        float waveStart = 0, lastBossLog = 0;
        int livesAtStart = g.lives, killsAtStart = 0;
        while (!g.over)
        {
            // Greedy but sensible: the first affordable action among the next three.
            for (int i = 0; i < Mathf.Min(3, plan.Count); i++)
                if (TryStep(plan[i])) { plan.RemoveAt(i); step++; i = -1; }
            EmergencyBuild();

            if (!g.waveRunning && g.NextWave)
            {
                if (g.wave > 0) LogWaveEnd(livesAtStart, killsAtStart, waveStart);
                post = CommanderSpot();
                cmdMinHp = g.commander.maxHp;
                g.commander.MoveTo(post);
                livesAtStart = g.lives;
                killsAtStart = g.kills;
                waveStart = Time.time;
                g.StartWave();
                Log($"wave={g.wave} start gold={g.gold} plan={step}/{step + plan.Count}");
            }

            ControlCommander();
            cmdMinHp = Mathf.Min(cmdMinHp, g.commander.hp);
            var boss = g.enemies.Find(e => e.data.isBoss);
            if (boss && Time.time - lastBossLog > 4)
            {
                lastBossLog = Time.time;
                Log($"boss hp={boss.hp:0}/{boss.data.maxHp:0} route={100 * boss.progress / g.map.Length:0}% enraged={boss.Enraged} " +
                    $"fightingCommander={boss.Engaged} summoned={g.summoned} enemies={g.enemies.Count} lives={g.lives} cmdHp={g.commander.hp:0}");
            }

            float t = Time.time - waveStart;
            if (g.wave == 1 && t > 16 && !shots.Contains("smoke_wave01.png"))
                yield return ShotWithGhost("smoke_wave01.png", g.level.towers[0], g.map.Position(g.map.Length * 0.55f, 0));
            if (g.wave == 5 && g.enemies.Count >= 12 && !shots.Contains("smoke_wave05.png"))
                yield return ShotWithSelection("smoke_wave05.png");
            if (g.wave == 10 && boss && boss.progress > g.map.Length * 0.3f && !shots.Contains("smoke_wave10.png"))
                yield return Shot("smoke_wave10.png");
            if (g.wave == 10 && boss && boss.Enraged && !shots.Contains("smoke_wave10_enraged.png"))
                yield return Shot("smoke_wave10_enraged.png");
            yield return new WaitForSeconds(0.25f);
        }

        if (g.victory) LogWaveEnd(livesAtStart, killsAtStart, waveStart);
        Log($"END victory={g.victory} wave={g.wave} lives={g.lives} kills={g.kills} leaks={g.leaks} gold={g.gold} " +
            $"summoned={g.summoned} errors={errors} reason=\"{g.endReason}\" towers=[{Towers()}]");
        Log("damage total: " + Share(g.damageBySource));
        Log("damage vs boss: " + Share(g.bossDamageBySource));
        yield return Shot("smoke_end.png");
        yield return new WaitForSecondsRealtime(1f);
        Application.Quit();
    }

    // ---------------------------------------------------------------- decisions

    bool TryStep(string s)
    {
        var t = g.level.towers["ABPC".IndexOf(s[1])];
        if (s[0] == '+')
        {
            if (g.gold < t.cost) return false;
            var spot = BestSpot(t);
            var tower = spot.HasValue ? g.TryBuild(t, spot.Value) : null;
            if (tower) built.Add(tower);
            else Log($"could not place {t.displayName}");
            return true;
        }
        var tower = built.Where(x => x && x.data == t).ElementAtOrDefault(int.Parse(s.Substring(2)));
        if (!tower || !tower.NextUpgrade) return true;
        return g.gold >= tower.NextUpgrade.cost && g.TryUpgrade(tower);
    }

    // With the boss alive, idle gold goes into towers covering the road the boss still has to walk.
    void EmergencyBuild()
    {
        var boss = g.enemies.Find(e => e.data.isBoss);
        if (!boss) return;
        foreach (var t in new[] { g.level.towers[1], g.level.towers[2] })
            if (g.gold >= t.cost && BestSpot(t, Mathf.Max(boss.progress + 3, g.map.Length * 0.6f)) is Vector2 p && g.TryBuild(t, p))
                Log($"emergency {t.displayName} at {p} boss route={100 * boss.progress / g.map.Length:0}%");
    }

    Vector2? BestSpot(TowerData t, float fromRoute = 0)
    {
        Vector2? best = null;
        float bestScore = -1;
        for (float x = -14f; x <= 14f; x += 0.25f)
            for (float y = -6.2f; y <= 4.5f; y += 0.25f)
            {
                var p = new Vector2(x, y);
                if (!g.CanBuild(t, p, out _, ignoreGold: true)) continue;
                float score = t.stats.auraRadius > 0 ? AuraScore(p, t.stats.auraRadius) : Coverage(p, t.stats.range, fromRoute);
                if (score > bestScore) { bestScore = score; best = p; }
            }
        return best;
    }

    // Visible road length within range, favouring the stretch closer to the fortress.
    float Coverage(Vector2 p, float range, float fromRoute = 0)
    {
        float n = 0;
        for (float s = fromRoute; s < g.map.Length; s += 0.5f)
        {
            var q = g.map.Position(s, 0);
            if (q.x > -15 && Vector2.Distance(p, q) <= range) n += 1 + s / g.map.Length;
        }
        return n;
    }

    float AuraScore(Vector2 p, float radius)
    {
        float score = g.towers.Where(t => !t.IsSupport && Vector2.Distance(t.Pos, p) <= radius).Sum(t => t.invested);
        return score + (Vector2.Distance(CommanderSpot(), p) <= radius ? 150 : 0);
    }

    // Last line of defense: the best-supported road point in the final stretch (chapel counts double).
    Vector2 CommanderSpot()
    {
        Vector2 best = Map.CommanderStart;
        float bestScore = 0;
        for (float s = g.map.Length * 0.7f; s < g.map.Length * 0.9f; s += 0.5f)
        {
            var p = g.map.Position(s, 0);
            float score = g.towers.Count(t => !t.IsSupport && Vector2.Distance(t.Pos, p) <= t.Effective().range)
                          + 2 * g.towers.Count(t => t.IsSupport && Vector2.Distance(t.Pos, p) <= t.stats.auraRadius);
            if (score >= bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    // A careful player: step off the road while the boss walks by, heal at a chapel when hurt, else hold the post.
    void ControlCommander()
    {
        var c = g.commander;
        if (!c.Alive || g.over) return;
        var boss = g.enemies.Find(e => e.data.isBoss);
        if (boss && Vector2.Distance(boss.transform.position, c.transform.position) < 3.6f)
        {
            c.MoveTo(SideStep(boss));
            return;
        }
        if (c.hp < c.maxHp * 0.35f)
        {
            var chapel = g.towers.FirstOrDefault(t => t.IsSupport);
            if (chapel) { c.MoveTo(chapel.Pos + new Vector2(0.9f, -0.3f)); return; }
        }
        if (!boss || Vector2.Distance(boss.transform.position, post) > 4.5f) c.MoveTo(post);
    }

    // A point beside the boss, off the road, far from every stretch of road.
    Vector2 SideStep(Enemy boss)
    {
        Vector2 best = g.commander.transform.position;
        float bestScore = float.MinValue;
        for (float a = 0; a < 360; a += 30)
        {
            var p = Map.ClampWalk((Vector2)boss.transform.position + (Vector2)(Quaternion.Euler(0, 0, a) * Vector3.right) * 3.2f);
            float score = Mathf.Min(g.map.DistanceToRoad(p), 2.5f) * 2 + Vector2.Distance(p, boss.transform.position);
            if (score > bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    // ---------------------------------------------------------------- screenshots and logs

    IEnumerator ShotWithGhost(string file, TowerData tower, Vector2? at)
    {
        g.building = tower;
        g.previewAt = at ?? BestSpot(tower) ?? Vector2.zero;
        yield return null;
        yield return Shot(file);
        g.building = null;
        g.previewAt = null;
    }

    IEnumerator ShotWithSelection(string file)
    {
        var t = g.towers.OrderByDescending(x => x.invested).FirstOrDefault(x => !x.IsSupport);
        g.Select(t);
        yield return null;
        yield return Shot(file);
        g.Select(null);
    }

    IEnumerator Shot(string file)
    {
        shots.Add(file);
        yield return new WaitForEndOfFrame();
        ScreenCapture.CaptureScreenshot(file);
        yield return null;
        Log($"screenshot {file}");
    }

    void LogWaveEnd(int livesAtStart, int killsAtStart, float waveStart) =>
        Log($"wave={g.wave} end lives={g.lives} (-{livesAtStart - g.lives}) kills={g.kills - killsAtStart} gold={g.gold} " +
            $"secs={Time.time - waveStart:0} cmdMinHp={cmdMinHp:0}/{g.commander.maxHp:0} towers=[{Towers()}]");

    string Towers() => string.Join(" ", g.towers.Select(t => $"{t.data.name}{t.level}"));

    static string Share(Dictionary<string, float> d)
    {
        float total = Mathf.Max(1, d.Values.Sum());
        return string.Join(", ", d.OrderByDescending(x => x.Value).Select(x => $"{x.Key} {100 * x.Value / total:0}% ({x.Value:0})"));
    }

    static void Log(string s) => Debug.Log("SMOKE " + s);
}
