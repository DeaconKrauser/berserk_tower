using UnityEngine;

// Preview of the tower being placed: follows the mouse, green when valid, red when not.
public class BuildGhost : MonoBehaviour
{
    static readonly Color32 Ok = new(110, 255, 130, 255), Bad = new(255, 70, 70, 255);
    SpriteRenderer body, range, foot;

    void Awake()
    {
        body = Gfx.Renderer(transform, "Body", null, Vector2.zero, Gfx.OrderGhost);
        range = Gfx.Renderer(transform, "Range", null, Vector2.zero, Gfx.OrderOverlay);
        foot = Gfx.Renderer(transform, "Foot", null, Vector2.zero, Gfx.OrderOverlay + 1);
        gameObject.SetActive(false);
    }

    public void Show(TowerData d, Vector2 at, bool valid)
    {
        gameObject.SetActive(true);
        transform.position = at;
        var c = valid ? Ok : Bad;
        body.sprite = d.sprite;
        body.color = new Color32(c.r, c.g, c.b, 170);
        range.sprite = Gfx.Circle(d.stats.auraRadius > 0 ? d.stats.auraRadius : d.stats.range, new Color32(c.r, c.g, c.b, 22), new Color32(c.r, c.g, c.b, 170));
        foot.sprite = Gfx.Circle(d.footprintRadius, new Color32(c.r, c.g, c.b, 70), c);
    }

    public void Hide() => gameObject.SetActive(false);
}
