using System.Collections.Generic;
using UnityEngine;

// Click him, click the ground: he walks there. Right-click moves him directly.
// Auto-attacks with a wide swing, holds up to N common enemies; bosses always stop to fight. Death = defeat.
public class Commander : MonoBehaviour
{
    static readonly int MovingId = Animator.StringToHash("Moving"), AttackId = Animator.StringToHash("Attack"),
        HitId = Animator.StringToHash("Hit"), DeadId = Animator.StringToHash("Dead");

    public float hp, maxHp;
    public bool Alive => hp > 0;

    LevelData L;
    Animator anim;
    SpriteRenderer sr, ring;
    Bar bar;
    Vector2 target;
    bool back;
    float attackTimer, hitCooldown;
    readonly List<Enemy> engaged = new(), swing = new();

    public void Init(LevelData level, Vector2 at)
    {
        L = level;
        hp = maxHp = level.commanderHp;
        transform.position = target = at;
        sr = gameObject.AddComponent<SpriteRenderer>();
        sr.spriteSortPoint = SpriteSortPoint.Pivot;
        anim = gameObject.AddComponent<Animator>();
        anim.runtimeAnimatorController = level.commanderFront;
        Gfx.Shadow(transform, 1.1f);
        ring = Gfx.Renderer(transform, "Ring", Gfx.Ellipse(52, 18, new Color32(242, 163, 58, 40), new Color32(242, 163, 58, 255)), Vector2.zero, Gfx.OrderOverlay);
        bar = new Bar(transform, new Vector2(0, 2.55f), 1.2f, Gfx.CommanderHp);
    }

    public bool Hit(Vector2 p) =>
        Mathf.Abs(p.x - transform.position.x) < 0.7f && p.y > transform.position.y - 0.3f && p.y < transform.position.y + 2.3f;

    public void MoveTo(Vector2 p) => target = Map.ClampWalk(p);

    public void HealFull() => hp = maxHp;

    public bool TryEngage(Enemy e)
    {
        if (engaged.Contains(e)) return true;
        if (!e.data.isBoss && engaged.FindAll(x => !x.data.isBoss).Count >= L.commanderBlockCount) return false;
        engaged.Add(e);
        return true;
    }

    public void Release(Enemy e) => engaged.Remove(e);

    public void TakeDamage(float amount)
    {
        if (!Alive || Game.I.over) return;
        hp -= amount;
        if (hp <= 0)
        {
            hp = 0;
            anim.SetBool(DeadId, true);
            anim.SetBool(MovingId, false);
            bar.root.SetActive(false);
            Game.I.Defeat("O comandante caiu. Sem ele, o bastião não resiste.");
            return;
        }
        if (hitCooldown <= 0)
        {
            hitCooldown = 0.5f;
            anim.SetTrigger(HitId);
        }
    }

    void Update()
    {
        ring.enabled = Alive && Game.I.commanderSelected;
        if (!Alive || Game.I.over) return;
        float dt = Time.deltaTime;
        hitCooldown -= dt;
        hp = Mathf.Min(maxHp, hp + Game.I.CommanderHealAt(transform.position) * dt);

        Vector2 pos = transform.position, to = target - pos;
        bool moving = to.sqrMagnitude > 0.0004f;
        if (moving)
        {
            Face(to);
            transform.position = Vector2.MoveTowards(pos, target, L.commanderSpeed * dt);
        }

        if ((attackTimer -= dt) <= 0 && PickSwing() > 0)
        {
            attackTimer = L.commanderAttackInterval;
            Face((Vector2)swing[0].transform.position - pos);
            anim.SetTrigger(AttackId);
            foreach (var e in swing) e.Damage(L.commanderDamage, DamageType.Physical, L.commanderArmorPenetration, "Comandante");
        }
        anim.SetBool(MovingId, moving);
        bar.Set(hp / maxHp);
    }

    // Enemies he is holding first, then the closest ones inside his reach.
    int PickSwing()
    {
        swing.Clear();
        engaged.RemoveAll(e => !e || !e.Alive);
        foreach (var e in engaged)
            if (swing.Count < L.commanderCleave) swing.Add(e);
        Vector2 pos = transform.position;
        while (swing.Count < L.commanderCleave)
        {
            Enemy best = null;
            float bestD = L.commanderReach;
            foreach (var e in Game.I.enemies)
            {
                float d = Vector2.Distance(pos, e.transform.position);
                if (d <= bestD && !swing.Contains(e)) { best = e; bestD = d; }
            }
            if (!best) break;
            swing.Add(best);
        }
        return swing.Count;
    }

    // Back view when heading mostly up the screen; the two views are separate animator overrides.
    void Face(Vector2 dir)
    {
        bool up = dir.y > Mathf.Abs(dir.x);
        if (up != back)
        {
            back = up;
            anim.runtimeAnimatorController = back ? L.commanderBack : L.commanderFront;
        }
        if (Mathf.Abs(dir.x) > 0.01f) sr.flipX = dir.x < 0;
    }
}
