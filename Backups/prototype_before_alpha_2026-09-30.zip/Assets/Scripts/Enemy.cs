using System.Collections;
using UnityEngine;
using UnityEngine.Rendering.Universal;

// Walks the shared route with its own lateral lane; never overlaps others (side-steps or queues).
// Gameplay runs on timers only; the Animator is purely visual.
public class Enemy : MonoBehaviour
{
    static readonly int MovingId = Animator.StringToHash("Moving"), AttackId = Animator.StringToHash("Attack"),
        HitId = Animator.StringToHash("Hit"), DeadId = Animator.StringToHash("Dead");
    const float CorpseSeconds = 1.6f, SideStepSpeed = 1.4f;

    public EnemyData data;
    public float hp, progress, lane;
    public bool Alive => hp > 0;
    public bool Enraged { get; private set; }
    public bool Engaged { get; private set; }
    public float Speed => data.speed * (Enraged ? data.enrageSpeedMultiplier : 1);
    public Vector2 Center => (Vector2)transform.position + Vector2.up * (height * 0.45f);

    Map map;
    Animator anim;
    SpriteRenderer sr;
    Bar bar;
    Light2D glow;
    float height, attackTimer, summonTimer, burnDps, burnLeft, hitCooldown;
    string burnSource;
    bool measured, announcedSummon;
    static int serial;
    readonly int id = ++serial;   // stable tie-break when two enemies stand exactly side by side

    public void Init(EnemyData d, float startProgress, float startLane)
    {
        data = d;
        hp = d.maxHp;
        progress = startProgress;
        lane = startLane;
        map = Game.I.map;
        height = d.bodyRadius * 6;
        summonTimer = d.summonInterval;
        transform.position = map.Position(progress, lane);
        sr = gameObject.AddComponent<SpriteRenderer>();
        sr.spriteSortPoint = SpriteSortPoint.Pivot;
        anim = gameObject.AddComponent<Animator>();
        anim.runtimeAnimatorController = d.animator;
        Gfx.Shadow(transform, d.bodyRadius * 2.6f);
        bar = new Bar(transform, new Vector2(0, height), Mathf.Clamp(d.bodyRadius * 2.6f, 0.7f, 1.6f), Gfx.EnemyHp);
        bar.root.SetActive(false);
        if (d.lightRadius > 0) glow = Gfx.Light(transform, new Vector2(0, height * 0.5f), d.lightColor, d.lightRadius, 0.9f);
    }

    void Update()
    {
        if (!Alive) return;
        var g = Game.I;
        if (g.over) { anim.SetBool(MovingId, false); return; }
        float dt = Time.deltaTime;
        hitCooldown -= dt;
        if (burnLeft > 0)
        {
            burnLeft -= dt;
            Damage(burnDps * dt, DamageType.Fire, 0, burnSource);
            if (!Alive) return;
        }
        if (data.isBoss) BossUpdate(dt);

        float x = transform.position.x;
        Engaged = Fight(dt);
        if (!Engaged) Walk(dt);
        float dx = transform.position.x - x;
        if (!Engaged && Mathf.Abs(dx) > 0.0005f) sr.flipX = dx < 0;
        anim.SetBool(MovingId, !Engaged);

        if (progress >= map.Length)
        {
            g.Leak(this);
            Destroy(gameObject);
        }
    }

    void LateUpdate()
    {
        // Bar height from the first real frame; frame count/size never feeds gameplay.
        if (measured || !sr.sprite) return;
        measured = true;
        height = sr.sprite.bounds.max.y;
        bar.root.transform.localPosition = new Vector2(0, height + 0.15f);
        if (glow) glow.transform.localPosition = new Vector2(0, height * 0.5f);
    }

    void Walk(float dt)
    {
        float next = progress + Speed * dt;
        float maxLane = Mathf.Max(0, Map.RoadHalfWidth - data.bodyRadius - 0.05f);
        foreach (var o in Game.I.enemies)
        {
            if (o == this) continue;
            float gap = data.bodyRadius + o.data.bodyRadius;
            float ds = o.progress - progress;
            if (ds > gap * 1.5f || ds < -gap * 1.5f) continue;
            float dl = lane - o.lane;
            if (Mathf.Abs(dl) >= gap * 0.85f) continue;
            // Too close: step aside, and never walk through whoever is in front.
            float away = dl != 0 ? Mathf.Sign(dl) : (id < o.id ? 1 : -1);
            lane += away * SideStepSpeed * dt;
            if (ds > 0) next = Mathf.Min(next, o.progress - gap * 0.9f);
        }
        lane = Mathf.Clamp(lane, -maxLane, maxLane);
        progress = Mathf.Max(progress, next);
        transform.position = map.Position(progress, lane);
    }

    // Stops to fight the commander when he is in reach and still has a free block slot.
    bool Fight(float dt)
    {
        var c = Game.I.commander;
        float reach = data.bodyRadius + 0.5f + (Engaged ? 0.35f : 0);
        bool inReach = c.Alive && Vector2.Distance(transform.position, c.transform.position) <= reach;
        if (!inReach || !c.TryEngage(this))
        {
            if (Engaged) c.Release(this);
            return false;
        }
        if (!Engaged) attackTimer = data.attackInterval * 0.4f;
        sr.flipX = c.transform.position.x < transform.position.x;
        if ((attackTimer -= dt) <= 0)
        {
            attackTimer = data.attackInterval;
            anim.SetTrigger(AttackId);
            c.TakeDamage(data.attackDamage);
        }
        return true;
    }

    void BossUpdate(float dt)
    {
        if (data.summon && data.summonCount > 0 && (summonTimer -= dt) <= 0)
        {
            summonTimer = data.summonInterval;
            for (int i = 0; i < data.summonCount; i++)
                Game.I.Spawn(data.summon, progress + 1.4f + i * 0.8f, Random.Range(-0.4f, 0.4f));
            anim.SetTrigger(AttackId);
            if (!announcedSummon) Game.I.hud.Banner($"{data.displayName} ergue os mortos!");
            announcedSummon = true;
            Game.I.summoned += data.summonCount;
        }
        if (!Enraged && data.enrageBelowHp > 0 && hp <= data.maxHp * data.enrageBelowHp)
        {
            Enraged = true;
            sr.color = new Color(1f, 0.78f, 0.78f);
            if (glow) { glow.color = new Color(1f, 0.15f, 0.15f); glow.intensity *= 1.6f; }
            Game.I.hud.Banner($"{data.displayName} enfurece!");
        }
    }

    // Where the enemy will stand after `seconds` of walking (for slow, ground-targeted projectiles).
    public Vector2 Predict(float seconds) =>
        Engaged ? (Vector2)transform.position : map.Position(progress + Speed * seconds, lane);

    public void Hit(TowerStats s, string source)
    {
        Damage(s.damage, s.damageType, s.armorPenetration, source);
        if (!Alive || s.burnDps <= 0) return;
        burnSource = source;
        burnDps = burnLeft > 0 ? Mathf.Max(burnDps, s.burnDps) : s.burnDps;
        burnLeft = Mathf.Max(burnLeft, s.burnDuration);
    }

    public float Armor => Mathf.Max(0, data.armor - Game.I.ArmorShredAt(transform.position));

    public void Damage(float amount, DamageType type, float penetration, string source)
    {
        if (!Alive || amount <= 0) return;
        float dealt = type == DamageType.Physical
            ? Mathf.Max(amount * Game.I.level.minPhysicalDamage, amount - Mathf.Max(0, Armor - penetration)) * (1 - data.physicalResistance)
            : amount * (1 - data.fireResistance);
        Game.I.RecordDamage(source, Mathf.Min(dealt, hp), data.isBoss);
        hp -= dealt;
        if (!data.isBoss)
        {
            bar.root.SetActive(true);
            bar.Set(hp / data.maxHp);
        }
        if (hp <= 0) Die();
        else if (hitCooldown <= 0 && dealt >= data.maxHp * 0.05f)
        {
            hitCooldown = 0.4f;
            anim.SetTrigger(HitId);
        }
    }

    void Die()
    {
        hp = 0;
        Game.I.Killed(this);
        anim.SetBool(DeadId, true);
        anim.SetBool(MovingId, false);
        bar.root.SetActive(false);
        if (glow) glow.enabled = false;
        StartCoroutine(Corpse());
    }

    IEnumerator Corpse()
    {
        yield return new WaitForSeconds(CorpseSeconds);
        for (float t = 0; t < 0.6f; t += Time.deltaTime)
        {
            sr.color = new Color(sr.color.r, sr.color.g, sr.color.b, 1 - t / 0.6f);
            yield return null;
        }
        Destroy(gameObject);
    }
}
