# O Último Bastião — vertical slice

## Rodar
Esta pasta já é o projeto Unity (6000.6.3f1, template 2D URP).
1. Unity Hub → Add → Add project from disk → `G:\berserk_tower`.
2. Abra `Assets/Scenes/SampleScene` e aperte Play. O jogo se monta sozinho via código (`Game.cs`), sem prefabs.

Build: `Unity.exe -batchmode -quit -projectPath . -executeMethod Build.Windows` → `Build/Bastiao.exe`.
Smoke test: `Build/Bastiao.exe -smoketest` joga as 10 ondas a 4× sozinho e salva screenshots em `Build/Bastiao_Data/`.

Se o comandante não aparecer: botão direito em `Assets/Resources/Sprites` → Reimport (o `PixelArtImporter` aplica PPU 32 / Point / pivot nos pés).

## Controles
- Clique no slot cinza (preparação): constrói torre (60) / melhora (50, até nv 3)
- Clique no comandante → clique no chão: move. Ataca sozinho quem chegar perto.
- Botão **Iniciar Onda** no canto superior direito.

## Arte
- Real: comandante ↘/↗ (`commander_se/ne.png`). O `spearman.png` já está recortado, mas ainda não entra no jogo.
- Placeholder (blocos coloridos no tamanho do asset-spec): inimigos, boss, torres, fortaleza, flecha, chão.
- `tools/cut_sheet.py`: recorta figuras separadas de uma design sheet magenta.
- `tools/slice_strip.py`: fatia tiras de animação (só funciona se os frames não se sobrepõem).
